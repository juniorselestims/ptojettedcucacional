from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.library import Book, db
from src.models.user import User

library_bp = Blueprint('library', __name__)

@library_bp.route('/books', methods=['GET'])
@jwt_required()
def get_books():
    title = request.args.get('title')
    author = request.args.get('author')
    discipline_id = request.args.get('discipline_id')
    
    query = Book.query
    
    if title:
        query = query.filter(Book.title.ilike(f'%{title}%'))
    
    if author:
        query = query.filter(Book.author.ilike(f'%{author}%'))
    
    if discipline_id:
        query = query.filter_by(discipline_id=discipline_id)
    
    books = query.all()
    
    return jsonify([{
        'id': book.id,
        'title': book.title,
        'author': book.author,
        'discipline_id': book.discipline_id,
        'pdf_url': book.pdf_url
    } for book in books]), 200

@library_bp.route('/books/<int:book_id>', methods=['GET'])
@jwt_required()
def get_book(book_id):
    book = Book.query.get(book_id)
    if not book:
        return jsonify({'message': 'Livro não encontrado'}), 404
    
    return jsonify({
        'id': book.id,
        'title': book.title,
        'author': book.author,
        'discipline_id': book.discipline_id,
        'pdf_url': book.pdf_url
    }), 200

@library_bp.route('/books', methods=['POST'])
@jwt_required()
def create_book():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    title = data.get('title')
    author = data.get('author')
    discipline_id = data.get('discipline_id')
    pdf_url = data.get('pdf_url')
    
    if not title or not author or not pdf_url:
        return jsonify({'message': 'Título, autor e URL do PDF são obrigatórios'}), 400
    
    new_book = Book(
        title=title,
        author=author,
        discipline_id=discipline_id,
        pdf_url=pdf_url
    )
    
    db.session.add(new_book)
    db.session.commit()
    
    return jsonify({'message': 'Livro criado com sucesso', 'id': new_book.id}), 201

@library_bp.route('/books/<int:book_id>', methods=['PUT'])
@jwt_required()
def update_book(book_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    book = Book.query.get(book_id)
    if not book:
        return jsonify({'message': 'Livro não encontrado'}), 404
    
    data = request.get_json()
    book.title = data.get('title', book.title)
    book.author = data.get('author', book.author)
    book.discipline_id = data.get('discipline_id', book.discipline_id)
    book.pdf_url = data.get('pdf_url', book.pdf_url)
    
    db.session.commit()
    
    return jsonify({'message': 'Livro atualizado com sucesso'}), 200

@library_bp.route('/books/<int:book_id>', methods=['DELETE'])
@jwt_required()
def delete_book(book_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    book = Book.query.get(book_id)
    if not book:
        return jsonify({'message': 'Livro não encontrado'}), 404
    
    db.session.delete(book)
    db.session.commit()
    
    return jsonify({'message': 'Livro excluído com sucesso'}), 200

