import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import json
from datetime import datetime

class NotificationService:
    def __init__(self):
        # Configurações de e-mail (em um ambiente real, seriam obtidas de variáveis de ambiente)
        self.email_sender = os.getenv('EMAIL_SENDER', 'noreply@projettdigital.com.br')
        self.email_password = os.getenv('EMAIL_PASSWORD', 'your_email_password')
        self.smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        
        # Configurações de WhatsApp (em um ambiente real, seriam obtidas de variáveis de ambiente)
        self.whatsapp_api_key = os.getenv('WHATSAPP_API_KEY', 'your_whatsapp_api_key')
        self.whatsapp_api_url = os.getenv('WHATSAPP_API_URL', 'https://api.whatsapp.com/v1/messages')
    
    def send_email(self, recipient, subject, message, html_message=None):
        """
        Envia um e-mail
        
        Args:
            recipient (str): Endereço de e-mail do destinatário
            subject (str): Assunto do e-mail
            message (str): Corpo do e-mail em texto plano
            html_message (str, optional): Corpo do e-mail em HTML
            
        Returns:
            bool: True se o e-mail foi enviado com sucesso
        """
        # Em um ambiente real, enviaríamos o e-mail via SMTP
        # Aqui estamos simulando o envio
        
        # Simular envio de e-mail
        print(f"Simulando envio de e-mail para {recipient}")
        print(f"Assunto: {subject}")
        print(f"Mensagem: {message}")
        
        # Simular sucesso
        return True
    
    def send_whatsapp(self, phone_number, message):
        """
        Envia uma mensagem de WhatsApp
        
        Args:
            phone_number (str): Número de telefone do destinatário (com código do país)
            message (str): Mensagem a ser enviada
            
        Returns:
            bool: True se a mensagem foi enviada com sucesso
        """
        # Em um ambiente real, enviaríamos a mensagem via API do WhatsApp
        # Aqui estamos simulando o envio
        
        # Simular envio de WhatsApp
        print(f"Simulando envio de WhatsApp para {phone_number}")
        print(f"Mensagem: {message}")
        
        # Simular sucesso
        return True
    
    def send_payment_reminder(self, invoice, user):
        """
        Envia um lembrete de pagamento por e-mail e WhatsApp
        
        Args:
            invoice (Invoice): Objeto da fatura
            user (User): Objeto do usuário
            
        Returns:
            dict: Resultado do envio das notificações
        """
        # Formatar data de vencimento
        due_date = invoice.due_date.strftime("%d/%m/%Y")
        
        # Preparar mensagem de e-mail
        subject = f"Lembrete de Pagamento - Vencimento em {due_date}"
        message = f"""
        Olá {user.name},
        
        Este é um lembrete de que você tem uma fatura com vencimento em {due_date}.
        
        Valor: R$ {invoice.value:.2f}
        
        Para efetuar o pagamento, acesse sua área do aluno em nosso sistema.
        
        Atenciosamente,
        Equipe PROJETT DIGITAL EAD
        """
        
        # Preparar mensagem de WhatsApp
        whatsapp_message = f"Olá {user.name}, você tem uma fatura de R$ {invoice.value:.2f} com vencimento em {due_date}. Acesse o sistema para efetuar o pagamento."
        
        # Enviar notificações
        email_sent = self.send_email(user.email, subject, message)
        
        # Verificar se o usuário tem número de telefone cadastrado
        phone_number = getattr(user, 'phone', None)
        whatsapp_sent = False
        if phone_number:
            whatsapp_sent = self.send_whatsapp(phone_number, whatsapp_message)
        
        # Resultado
        result = {
            "email_sent": email_sent,
            "whatsapp_sent": whatsapp_sent,
            "timestamp": datetime.now().isoformat()
        }
        
        return result
    
    def send_new_lesson_notification(self, lesson, users):
        """
        Notifica os alunos sobre uma nova aula
        
        Args:
            lesson (Lesson): Objeto da aula
            users (list): Lista de objetos de usuários a serem notificados
            
        Returns:
            dict: Resultado do envio das notificações
        """
        # Preparar mensagem de e-mail
        subject = f"Nova Aula Disponível: {lesson.title}"
        
        results = {
            "total_users": len(users),
            "emails_sent": 0,
            "whatsapp_sent": 0,
            "timestamp": datetime.now().isoformat()
        }
        
        for user in users:
            # Mensagem de e-mail personalizada
            message = f"""
            Olá {user.name},
            
            Uma nova aula foi disponibilizada em nosso sistema:
            
            Título: {lesson.title}
            Tipo: {"Videoaula" if lesson.lesson_type == "Video" else "Aula ao Vivo"}
            Data: {lesson.lesson_date.strftime("%d/%m/%Y %H:%M") if lesson.lesson_date else "Não definida"}
            
            Acesse sua área do aluno para assistir.
            
            Atenciosamente,
            Equipe PROJETT DIGITAL EAD
            """
            
            # Enviar e-mail
            email_sent = self.send_email(user.email, subject, message)
            if email_sent:
                results["emails_sent"] += 1
            
            # Verificar se o usuário tem número de telefone cadastrado
            phone_number = getattr(user, 'phone', None)
            if phone_number:
                # Mensagem de WhatsApp personalizada
                whatsapp_message = f"Olá {user.name}, uma nova aula '{lesson.title}' foi disponibilizada. Acesse o sistema para assistir."
                
                # Enviar WhatsApp
                whatsapp_sent = self.send_whatsapp(phone_number, whatsapp_message)
                if whatsapp_sent:
                    results["whatsapp_sent"] += 1
        
        return results

