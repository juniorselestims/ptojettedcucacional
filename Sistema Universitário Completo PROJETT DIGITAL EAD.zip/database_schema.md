# Esquema do Banco de Dados - PROJETT DIGITAL EAD

## Entidades e Relacionamentos

### Usuários (Users)
- id (PK)
- nome
- email (unique)
- senha
- tipo (Admin, Coordenador, Professor, Aluno, Financeiro, Suporte)
- id_google (opcional)
- id_facebook (opcional)

### Cursos (Courses)
- id (PK)
- nome
- descricao
- coordenador_id (FK para Usuários)

### Disciplinas (Disciplines)
- id (PK)
- nome
- curso_id (FK para Cursos)

### Turmas (Classes)
- id (PK)
- nome
- disciplina_id (FK para Disciplinas)
- professor_id (FK para Usuários)
- ano_letivo

### Matrículas (Enrollments)
- id (PK)
- aluno_id (FK para Usuários)
- turma_id (FK para Turmas)
- data_matricula

### Aulas (Lessons)
- id (PK)
- titulo
- turma_id (FK para Turmas)
- tipo (Video, Live)
- url_video (para videoaulas)
- id_live (para aulas ao vivo)
- data_aula

### Materiais (Materials)
- id (PK)
- nome
- tipo (PDF, Slide, etc.)
- url_arquivo
- aula_id (FK para Aulas)

### Avaliações (Assessments)
- id (PK)
- titulo
- turma_id (FK para Turmas)
- tipo (Objetiva, Dissertativa, Múltipla Escolha)

### Questões (Questions)
- id (PK)
- enunciado
- tipo (Objetiva, Dissertativa, Múltipla Escolha)
- avaliacao_id (FK para Avaliações)

### Respostas (Answers)
- id (PK)
- aluno_id (FK para Usuários)
- questao_id (FK para Questões)
- resposta_texto
- resposta_opcao

### Notas (Grades)
- id (PK)
- aluno_id (FK para Usuários)
- avaliacao_id (FK para Avaliações)
- nota

### Frequência (Attendance)
- id (PK)
- aluno_id (FK para Usuários)
- aula_id (FK para Aulas)
- presente

### Planos de Mensalidades (TuitionPlans)
- id (PK)
- nome
- valor

### Boletos (Invoices)
- id (PK)
- aluno_id (FK para Usuários)
- plano_id (FK para Planos de Mensalidades)
- valor
- data_vencimento
- status (Pendente, Pago, Atrasado)

### Livros (Books)
- id (PK)
- titulo
- autor
- disciplina_id (FK para Disciplinas)
- url_pdf

### Chamados (Tickets)
- id (PK)
- aluno_id (FK para Usuários)
- atendente_id (FK para Usuários)
- titulo
- descricao
- status (Aberto, Em Andamento, Fechado)

## Relacionamentos

- Um **Coordenador** pode gerenciar vários **Cursos**.
- Um **Curso** pode ter várias **Disciplinas**.
- Uma **Disciplina** pode ter várias **Turmas**.
- Um **Professor** pode lecionar em várias **Turmas**.
- Um **Aluno** pode se matricular em várias **Turmas**.
- Uma **Turma** pode ter várias **Aulas** e **Avaliações**.
- Uma **Aula** pode ter vários **Materiais**.
- Uma **Avaliação** pode ter várias **Questões**.
- Um **Aluno** pode ter várias **Respostas**, **Notas** e registros de **Frequência**.
- Um **Aluno** pode ter vários **Boletos**.
- Uma **Disciplina** pode ter vários **Livros** na biblioteca.
- Um **Aluno** pode abrir vários **Chamados** de suporte.

