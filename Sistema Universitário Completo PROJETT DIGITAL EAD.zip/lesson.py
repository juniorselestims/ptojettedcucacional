from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.lesson import Lesson, db
from src.models.user import User
from datetime import datetime

lesson_bp = Blueprint('lesson', __name__)

@lesson_bp.route('/lessons', methods=['GET'])
@jwt_required()
def get_lessons():
    lessons = Lesson.query.all()
    return jsonify([{
        'id': lesson.id,
        'title': lesson.title,
        'class_id': lesson.class_id,
        'lesson_type': lesson.lesson_type,
        'video_url': lesson.video_url,
        'live_id': lesson.live_id,
        'lesson_date': lesson.lesson_date.isoformat() if lesson.lesson_date else None
    } for lesson in lessons]), 200

@lesson_bp.route('/lessons/<int:lesson_id>', methods=['GET'])
@jwt_required()
def get_lesson(lesson_id):
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({'message': 'Aula não encontrada'}), 404
    
    return jsonify({
        'id': lesson.id,
        'title': lesson.title,
        'class_id': lesson.class_id,
        'lesson_type': lesson.lesson_type,
        'video_url': lesson.video_url,
        'live_id': lesson.live_id,
        'lesson_date': lesson.lesson_date.isoformat() if lesson.lesson_date else None
    }), 200

@lesson_bp.route('/lessons', methods=['POST'])
@jwt_required()
def create_lesson():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    title = data.get('title')
    class_id = data.get('class_id')
    lesson_type = data.get('lesson_type')
    video_url = data.get('video_url')
    live_id = data.get('live_id')
    lesson_date = data.get('lesson_date')
    
    if not title or not class_id or not lesson_type:
        return jsonify({'message': 'Título, ID da turma e tipo da aula são obrigatórios'}), 400
    
    # Converter string de data para datetime se fornecida
    parsed_date = None
    if lesson_date:
        try:
            parsed_date = datetime.fromisoformat(lesson_date.replace('Z', '+00:00'))
        except ValueError:
            return jsonify({'message': 'Formato de data inválido'}), 400
    
    new_lesson = Lesson(
        title=title,
        class_id=class_id,
        lesson_type=lesson_type,
        video_url=video_url,
        live_id=live_id,
        lesson_date=parsed_date
    )
    
    db.session.add(new_lesson)
    db.session.commit()
    
    return jsonify({'message': 'Aula criada com sucesso', 'id': new_lesson.id}), 201

@lesson_bp.route('/lessons/<int:lesson_id>', methods=['PUT'])
@jwt_required()
def update_lesson(lesson_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({'message': 'Aula não encontrada'}), 404
    
    data = request.get_json()
    lesson.title = data.get('title', lesson.title)
    lesson.class_id = data.get('class_id', lesson.class_id)
    lesson.lesson_type = data.get('lesson_type', lesson.lesson_type)
    lesson.video_url = data.get('video_url', lesson.video_url)
    lesson.live_id = data.get('live_id', lesson.live_id)
    
    lesson_date = data.get('lesson_date')
    if lesson_date:
        try:
            lesson.lesson_date = datetime.fromisoformat(lesson_date.replace('Z', '+00:00'))
        except ValueError:
            return jsonify({'message': 'Formato de data inválido'}), 400
    
    db.session.commit()
    
    return jsonify({'message': 'Aula atualizada com sucesso'}), 200

@lesson_bp.route('/lessons/<int:lesson_id>', methods=['DELETE'])
@jwt_required()
def delete_lesson(lesson_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({'message': 'Aula não encontrada'}), 404
    
    db.session.delete(lesson)
    db.session.commit()
    
    return jsonify({'message': 'Aula excluída com sucesso'}), 200

