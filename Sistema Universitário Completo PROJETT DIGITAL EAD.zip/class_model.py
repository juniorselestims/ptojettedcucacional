from src.models.user import db

class Class(db.Model):
    __tablename__ = 'classes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    discipline_id = db.Column(db.Integer, db.ForeignKey('disciplines.id'), nullable=False)
    professor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    academic_year = db.Column(db.String(10), nullable=True)
    
    # Relacionamentos
    enrollments = db.relationship('Enrollment', backref='class_obj', lazy=True, cascade='all, delete-orphan')
    lessons = db.relationship('Lesson', backref='class_obj', lazy=True, cascade='all, delete-orphan')
    assessments = db.relationship('Assessment', backref='class_obj', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Class {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'discipline_id': self.discipline_id,
            'professor_id': self.professor_id,
            'academic_year': self.academic_year
        }

