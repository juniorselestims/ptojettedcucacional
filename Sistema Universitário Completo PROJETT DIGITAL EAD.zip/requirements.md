
# Requisitos do Sistema PROJETT DIGITAL EAD

## 1. Usuários do Sistema

### 1.1. Administrador
- Gestão geral do sistema.
- Acesso a todos os relatórios gerenciais (financeiro, acadêmico, engajamento).
- Gerenciamento de usuários (criação, edição, exclusão de todos os tipos de usuários).
- Configurações gerais do sistema (login, permissões).

### 1.2. Coordenador de Curso
- Gerenciamento de turmas, disciplinas e professores.
- Cadastro e gestão de cursos.
- Atribuição de professores a disciplinas e turmas.
- Acompanhamento do desempenho acadêmico das turmas.

### 1.3. Professor
- Criação e gestão de aulas (videoaulas, aulas ao vivo).
- Disponibilização de materiais (apostilas, PDFs, slides).
- Correção de atividades e provas.
- Lançamento de notas e frequência.
- Participação em fóruns e debates.

### 1.4. Aluno
- Acesso a aulas online (videoaulas, aulas ao vivo).
- Realização de atividades e provas.
- Acompanhamento de notas e histórico escolar.
- Acesso a boletos e controle de pagamentos.
- Participação em fóruns e debates.
- Download de materiais da biblioteca digital.

### 1.5. Financeiro
- Emissão de cobranças (boletos, PIX, cartão de crédito).
- Controle de pagamentos e inadimplência.
- Geração de relatórios financeiros.
- Envio automático de lembretes de pagamento.

### 1.6. Suporte/Atendente
- Atendimento a dúvidas e chamados dos alunos.
- Resposta a solicitações de suporte.

## 2. Funcionalidades

### 2.1. Acadêmico
- **Cadastro e gestão de cursos, disciplinas, turmas e matrículas:** CRUD completo para cada entidade.
- **Calendário acadêmico:** Visualização e gestão de datas de início/fim, provas, eventos.
- **Gestão de notas, frequência e histórico escolar:** Lançamento, edição e consulta de notas e frequência. Geração de histórico escolar.
- **Emissão de declarações e boletins em PDF:** Geração automática de documentos.

### 2.2. Aulas Online
- **Biblioteca de videoaulas:** Upload, armazenamento e reprodução de videoaulas.
- **Aulas ao vivo (live):** Integração com plataformas de streaming (Zoom, Google Meet, WebRTC) para aulas em tempo real com chat e lista de presença.
- **Upload de materiais:** Upload de apostilas, PDFs e slides pelos professores.
- **Fóruns e debates:** Criação e participação em fóruns de discussão.

### 2.3. Avaliações
- **Criação de provas online:** Suporte a questões objetivas, dissertativas e múltipla escolha.
- **Correção automática:** Para questões de múltipla escolha.
- **Relatório de desempenho por aluno:** Visualização detalhada do desempenho individual.

### 2.4. Financeiro
- **Cadastro de planos de mensalidades:** Definição de valores, datas de vencimento, etc.
- **Emissão automática de boletos, PIX, cartão de crédito:** Integração com gateways de pagamento (Mercado Pago, PayPal).
- **Controle de inadimplência:** Relatórios e ferramentas para gestão de alunos inadimplentes.
- **Envio automático de lembretes de pagamento:** Via e-mail e WhatsApp.

### 2.5. Biblioteca Digital
- **Upload de livros e artigos em PDF:** Armazenamento e organização de materiais.
- **Busca:** Por título, autor ou disciplina.
- **Download e leitura online:** Acesso facilitado aos materiais.

### 2.6. Configurações Gerais
- **Login:** Com usuário e senha, e integração com Google/Facebook.
- **Níveis de permissão:** Controle de acesso baseado nos perfis de usuário.
- **Relatórios gerenciais:** Financeiro, acadêmico, engajamento.
- **Painel de estatísticas:** Gráficos de alunos ativos, pagamentos, aulas assistidas.

