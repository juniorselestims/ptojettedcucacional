import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Plus, Pencil, Trash2, FileText, Search, BookOpen } from 'lucide-react';

const Books = () => {
  const { currentUser } = useAuth();
  const [books, setBooks] = useState([]);
  const [disciplines, setDisciplines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentBook, setCurrentBook] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    discipline_id: '',
    pdf_url: ''
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFilter, setSearchFilter] = useState('title');

  useEffect(() => {
    fetchBooks();
    fetchDisciplines();
  }, []);

  const fetchBooks = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/books');
      setBooks(response.data);
    } catch (error) {
      console.error('Erro ao buscar livros:', error);
      setError('Não foi possível carregar os livros. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchDisciplines = async () => {
    try {
      const response = await axios.get('/api/disciplines');
      setDisciplines(response.data);
    } catch (error) {
      console.error('Erro ao buscar disciplinas:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentBook) {
        await axios.put(`/api/books/${currentBook.id}`, formData);
      } else {
        await axios.post('/api/books', formData);
      }
      
      fetchBooks();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar livro:', error);
      setError(error.response?.data?.message || 'Erro ao salvar livro. Tente novamente.');
    }
  };

  const handleEdit = (book) => {
    setCurrentBook(book);
    setFormData({
      title: book.title,
      author: book.author,
      discipline_id: book.discipline_id || '',
      pdf_url: book.pdf_url
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir este livro?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/books/${id}`);
      fetchBooks();
    } catch (error) {
      console.error('Erro ao excluir livro:', error);
      setError(error.response?.data?.message || 'Erro ao excluir livro. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      author: '',
      discipline_id: '',
      pdf_url: ''
    });
    setCurrentBook(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchFilteredBooks();
  };

  const fetchFilteredBooks = async () => {
    try {
      setLoading(true);
      let url = '/api/books';
      
      if (searchQuery) {
        url += `?${searchFilter}=${encodeURIComponent(searchQuery)}`;
      }
      
      const response = await axios.get(url);
      setBooks(response.data);
    } catch (error) {
      console.error('Erro ao buscar livros:', error);
      setError('Erro ao buscar livros. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const canManageBooks = ['Admin', 'Coordenador', 'Professor'].includes(currentUser.user_type);
  
  // Agrupar livros por disciplina
  const booksByDiscipline = {};
  books.forEach(book => {
    const disciplineId = book.discipline_id || 'sem-disciplina';
    if (!booksByDiscipline[disciplineId]) {
      booksByDiscipline[disciplineId] = [];
    }
    booksByDiscipline[disciplineId].push(book);
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Biblioteca Digital</h1>
          <p className="text-gray-500">Acesse os livros e materiais disponíveis</p>
        </div>
        
        {canManageBooks && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Livro
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Livro' : 'Novo Livro'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações do livro abaixo.' 
                    : 'Preencha as informações para adicionar um novo livro.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="author">Autor</Label>
                  <Input
                    id="author"
                    name="author"
                    value={formData.author}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="discipline_id">Disciplina</Label>
                  <select
                    id="discipline_id"
                    name="discipline_id"
                    value={formData.discipline_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                  >
                    <option value="">Selecione uma disciplina</option>
                    {disciplines.map(discipline => (
                      <option key={discipline.id} value={discipline.id}>
                        {discipline.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="pdf_url">URL do PDF</Label>
                  <Input
                    id="pdf_url"
                    name="pdf_url"
                    value={formData.pdf_url}
                    onChange={handleChange}
                    placeholder="https://exemplo.com/livro.pdf"
                    required
                  />
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Adicionar Livro'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardHeader>
          <CardTitle>Pesquisar Livros</CardTitle>
          <CardDescription>Busque por título, autor ou disciplina</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearch} className="flex space-x-4">
            <div className="flex-1">
              <Input
                placeholder="Digite sua busca..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div>
              <select
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="h-10 rounded-md border border-gray-300 px-3"
              >
                <option value="title">Título</option>
                <option value="author">Autor</option>
                <option value="discipline_id">Disciplina</option>
              </select>
            </div>
            <Button type="submit">
              <Search className="mr-2 h-4 w-4" />
              Buscar
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">Todos os Livros</TabsTrigger>
          <TabsTrigger value="by-discipline">Por Disciplina</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Biblioteca Completa</CardTitle>
              <CardDescription>Todos os livros disponíveis</CardDescription>
            </CardHeader>
            <CardContent>
              {renderBooksTable(books)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="by-discipline" className="mt-4">
          <div className="space-y-6">
            {Object.entries(booksByDiscipline).map(([disciplineId, disciplineBooks]) => {
              const disciplineName = disciplines.find(d => d.id === parseInt(disciplineId))?.name || 'Sem Disciplina';
              
              return (
                <Card key={disciplineId}>
                  <CardHeader>
                    <CardTitle>{disciplineName}</CardTitle>
                    <CardDescription>{disciplineBooks.length} livros disponíveis</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {renderBooksTable(disciplineBooks)}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
  
  function renderBooksTable(booksData) {
    if (loading) {
      return (
        <div className="flex justify-center p-4">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      );
    }
    
    if (booksData.length === 0) {
      return <p className="text-center text-gray-500 py-4">Nenhum livro encontrado.</p>;
    }
    
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Título</TableHead>
              <TableHead>Autor</TableHead>
              <TableHead>Disciplina</TableHead>
              <TableHead className="w-24">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {booksData.map(book => (
              <TableRow key={book.id}>
                <TableCell className="font-medium">{book.title}</TableCell>
                <TableCell>{book.author}</TableCell>
                <TableCell>
                  {disciplines.find(d => d.id === book.discipline_id)?.name || 'Não atribuída'}
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <a href={book.pdf_url} target="_blank" rel="noopener noreferrer">
                      <Button variant="ghost" size="icon">
                        <FileText className="h-4 w-4" />
                      </Button>
                    </a>
                    <Link to={`/books/${book.id}`}>
                      <Button variant="ghost" size="icon">
                        <BookOpen className="h-4 w-4" />
                      </Button>
                    </Link>
                    {canManageBooks && (
                      <>
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(book)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(book.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }
};

export default Books;

