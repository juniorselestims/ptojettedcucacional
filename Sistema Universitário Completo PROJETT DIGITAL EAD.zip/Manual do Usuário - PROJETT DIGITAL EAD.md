# Manual do Usuário - PROJETT DIGITAL EAD

## Sumário

1. [Introdução](#introdução)
2. [Acesso ao Sistema](#acesso-ao-sistema)
3. [Interface do Usuário](#interface-do-usuário)
4. [Funcionalidades por Perfil](#funcionalidades-por-perfil)
   - [Administrador](#administrador)
   - [Coordenador de Curso](#coordenador-de-curso)
   - [Professor](#professor)
   - [Aluno](#aluno)
   - [Financeiro](#financeiro)
   - [Suporte/Atendente](#suporteatendente)
5. [Módulos do Sistema](#módulos-do-sistema)
   - [Acadêmico](#acadêmico)
   - [Aulas Online](#aulas-online)
   - [Avaliações](#avaliações)
   - [Financeiro](#financeiro-1)
   - [Biblioteca Digital](#biblioteca-digital)
   - [Suporte](#suporte)
6. [Perguntas Frequentes](#perguntas-frequentes)

## Introdução

O PROJETT DIGITAL EAD é um sistema universitário completo para ensino à distância, projetado para facilitar a gestão acadêmica, disponibilização de conteúdo online, avaliações, controle financeiro e suporte aos alunos.

Este manual fornece instruções detalhadas sobre como utilizar todas as funcionalidades do sistema, organizadas por perfil de usuário e módulos do sistema.

## Acesso ao Sistema

### Primeiro Acesso

1. Acesse o sistema através do endereço fornecido pela sua instituição (ex: https://ead.suainstituicao.com.br)
2. Na tela de login, clique em "Primeiro acesso" ou "Esqueci minha senha"
3. Informe o e-mail cadastrado
4. Você receberá um e-mail com instruções para criar sua senha
5. Siga as instruções do e-mail e defina uma senha segura

### Login no Sistema

1. Acesse o sistema através do endereço fornecido
2. Informe seu e-mail e senha
3. Clique no botão "Entrar"

Alternativamente, você pode fazer login usando sua conta do Google ou Facebook, se essas opções estiverem habilitadas pela sua instituição.

### Recuperação de Senha

1. Na tela de login, clique em "Esqueci minha senha"
2. Informe o e-mail cadastrado
3. Você receberá um e-mail com instruções para redefinir sua senha
4. Siga as instruções do e-mail e defina uma nova senha

## Interface do Usuário

### Visão Geral

Após fazer login, você verá a interface principal do sistema, que consiste em:

1. **Barra Superior**: Contém o logo da instituição, notificações e menu do usuário
2. **Menu Lateral**: Navegação principal para acessar os diferentes módulos do sistema
3. **Área de Conteúdo**: Exibe o conteúdo do módulo selecionado
4. **Rodapé**: Informações de contato e links úteis

### Menu Lateral

O menu lateral exibe as opções disponíveis de acordo com o seu perfil de usuário. As opções comuns incluem:

- **Dashboard**: Visão geral e estatísticas
- **Acadêmico**: Cursos, disciplinas, turmas e matrículas
- **Aulas**: Videoaulas e aulas ao vivo
- **Avaliações**: Provas e atividades
- **Financeiro**: Mensalidades e pagamentos
- **Biblioteca**: Acesso a materiais e livros digitais
- **Suporte**: Chamados e atendimento

### Notificações

O sistema envia notificações sobre eventos importantes, como:

- Novas aulas disponíveis
- Avaliações próximas do prazo
- Mensalidades a vencer
- Respostas de chamados de suporte

Para visualizar suas notificações, clique no ícone de sino na barra superior.

## Funcionalidades por Perfil

### Administrador

O administrador tem acesso completo ao sistema, podendo gerenciar todos os aspectos da plataforma.

#### Principais Funcionalidades:

- **Gestão de Usuários**:
  - Criar, editar e desativar usuários
  - Definir perfis e permissões
  - Importar usuários em lote

- **Configurações do Sistema**:
  - Personalizar aparência (logo, cores)
  - Configurar integrações (Zoom, gateway de pagamento)
  - Definir parâmetros acadêmicos e financeiros

- **Relatórios Gerenciais**:
  - Acessar estatísticas de uso
  - Gerar relatórios acadêmicos e financeiros
  - Monitorar desempenho do sistema

### Coordenador de Curso

O coordenador gerencia aspectos acadêmicos relacionados aos cursos sob sua responsabilidade.

#### Principais Funcionalidades:

- **Gestão de Cursos e Disciplinas**:
  - Criar e editar disciplinas
  - Definir grade curricular
  - Gerenciar conteúdo programático

- **Gestão de Turmas**:
  - Criar e gerenciar turmas
  - Atribuir professores às disciplinas
  - Definir calendário acadêmico

- **Acompanhamento Acadêmico**:
  - Monitorar desempenho dos alunos
  - Acompanhar frequência e participação
  - Gerar relatórios de desempenho

### Professor

O professor é responsável por criar conteúdo, ministrar aulas e avaliar os alunos.

#### Principais Funcionalidades:

- **Gestão de Aulas**:
  - Criar videoaulas
  - Agendar e realizar aulas ao vivo
  - Disponibilizar materiais complementares

- **Avaliações**:
  - Criar provas e atividades
  - Definir critérios de avaliação
  - Corrigir e atribuir notas

- **Interação com Alunos**:
  - Participar de fóruns de discussão
  - Responder dúvidas
  - Fornecer feedback sobre atividades

### Aluno

O aluno acessa o conteúdo das disciplinas, realiza atividades e interage com professores e colegas.

#### Principais Funcionalidades:

- **Acesso ao Conteúdo**:
  - Assistir videoaulas
  - Participar de aulas ao vivo
  - Baixar materiais complementares

- **Realização de Atividades**:
  - Responder avaliações
  - Enviar trabalhos
  - Verificar notas e feedback

- **Acompanhamento Acadêmico**:
  - Visualizar histórico escolar
  - Acompanhar frequência
  - Verificar calendário acadêmico

- **Financeiro**:
  - Visualizar mensalidades
  - Gerar boletos
  - Verificar histórico de pagamentos

### Financeiro

O usuário do setor financeiro gerencia aspectos relacionados a pagamentos e mensalidades.

#### Principais Funcionalidades:

- **Gestão de Mensalidades**:
  - Criar planos de pagamento
  - Gerar mensalidades
  - Aplicar descontos e bolsas

- **Controle de Pagamentos**:
  - Registrar pagamentos
  - Emitir recibos
  - Controlar inadimplência

- **Relatórios Financeiros**:
  - Gerar relatórios de receitas
  - Acompanhar fluxo de caixa
  - Analisar indicadores financeiros

### Suporte/Atendente

O atendente de suporte auxilia os usuários com dúvidas e problemas técnicos.

#### Principais Funcionalidades:

- **Gestão de Chamados**:
  - Receber e categorizar chamados
  - Responder dúvidas
  - Encaminhar problemas técnicos

- **Base de Conhecimento**:
  - Consultar soluções para problemas comuns
  - Criar artigos de ajuda
  - Atualizar FAQs

- **Comunicação com Usuários**:
  - Enviar notificações
  - Realizar atendimento por chat
  - Acompanhar satisfação dos usuários

## Módulos do Sistema

### Acadêmico

O módulo acadêmico gerencia cursos, disciplinas, turmas e matrículas.

#### Cursos

Para acessar a lista de cursos:
1. No menu lateral, clique em "Acadêmico"
2. Selecione "Cursos"

Para criar um novo curso (Administrador/Coordenador):
1. Na página de cursos, clique no botão "Novo Curso"
2. Preencha os campos obrigatórios (nome, descrição)
3. Selecione o coordenador responsável
4. Clique em "Salvar"

#### Disciplinas

Para acessar a lista de disciplinas:
1. No menu lateral, clique em "Acadêmico"
2. Selecione "Disciplinas"

Para criar uma nova disciplina (Administrador/Coordenador):
1. Na página de disciplinas, clique no botão "Nova Disciplina"
2. Preencha os campos obrigatórios (nome, curso)
3. Clique em "Salvar"

#### Turmas

Para acessar a lista de turmas:
1. No menu lateral, clique em "Acadêmico"
2. Selecione "Turmas"

Para criar uma nova turma (Administrador/Coordenador):
1. Na página de turmas, clique no botão "Nova Turma"
2. Preencha os campos obrigatórios (nome, disciplina, professor)
3. Defina o período acadêmico
4. Clique em "Salvar"

#### Matrículas

Para acessar a lista de matrículas:
1. No menu lateral, clique em "Acadêmico"
2. Selecione "Matrículas"

Para criar uma nova matrícula (Administrador/Coordenador):
1. Na página de matrículas, clique no botão "Nova Matrícula"
2. Selecione o aluno
3. Selecione a turma
4. Clique em "Salvar"

### Aulas Online

O módulo de aulas online gerencia videoaulas e aulas ao vivo.

#### Videoaulas

Para acessar a lista de videoaulas:
1. No menu lateral, clique em "Aulas"
2. Selecione "Videoaulas"

Para criar uma nova videoaula (Professor):
1. Na página de videoaulas, clique no botão "Nova Videoaula"
2. Preencha os campos obrigatórios (título, turma)
3. Informe a URL do vídeo (YouTube, Vimeo, etc.)
4. Adicione materiais complementares (opcional)
5. Clique em "Salvar"

Para assistir uma videoaula (Aluno):
1. Na página de videoaulas, localize a aula desejada
2. Clique no título da aula para acessar a página de detalhes
3. Clique no player de vídeo para iniciar a reprodução
4. Utilize os controles de reprodução para pausar, avançar ou retroceder

#### Aulas ao Vivo

Para acessar a lista de aulas ao vivo:
1. No menu lateral, clique em "Aulas"
2. Selecione "Aulas ao Vivo"

Para agendar uma nova aula ao vivo (Professor):
1. Na página de aulas ao vivo, clique no botão "Nova Aula ao Vivo"
2. Preencha os campos obrigatórios (título, turma, data/hora)
3. Clique em "Salvar"
4. O sistema criará automaticamente uma reunião no Zoom

Para participar de uma aula ao vivo (Aluno/Professor):
1. Na página de aulas ao vivo, localize a aula desejada
2. Próximo ao horário agendado, o botão "Entrar na Aula" ficará disponível
3. Clique no botão para ser redirecionado para a sala de videoconferência
4. Siga as instruções na tela para entrar na reunião

### Avaliações

O módulo de avaliações gerencia provas, atividades e notas.

#### Criar Avaliação

Para criar uma nova avaliação (Professor):
1. No menu lateral, clique em "Avaliações"
2. Clique no botão "Nova Avaliação"
3. Preencha os campos obrigatórios (título, turma, tipo de avaliação)
4. Defina a data de entrega
5. Clique em "Salvar"
6. Na página de detalhes da avaliação, clique em "Adicionar Questão"
7. Selecione o tipo de questão (objetiva, dissertativa, múltipla escolha)
8. Preencha o enunciado e as alternativas (se aplicável)
9. Defina o valor da questão
10. Clique em "Salvar"
11. Repita os passos 6-10 para adicionar mais questões
12. Quando finalizar, clique em "Publicar Avaliação"

#### Realizar Avaliação

Para realizar uma avaliação (Aluno):
1. No menu lateral, clique em "Avaliações"
2. Localize a avaliação desejada
3. Clique no título da avaliação para acessar a página de detalhes
4. Clique no botão "Iniciar Avaliação"
5. Responda às questões apresentadas
6. Utilize os botões "Anterior" e "Próximo" para navegar entre as questões
7. Clique em "Finalizar" quando terminar
8. Confirme o envio da avaliação

#### Corrigir Avaliação

Para corrigir uma avaliação (Professor):
1. No menu lateral, clique em "Avaliações"
2. Localize a avaliação desejada
3. Clique no botão "Corrigir" ao lado da avaliação
4. Na página de correção, você verá a lista de alunos que realizaram a avaliação
5. Clique no nome do aluno para visualizar suas respostas
6. Para questões objetivas ou de múltipla escolha, a correção é automática
7. Para questões dissertativas, atribua uma nota e forneça feedback
8. Clique em "Salvar" para cada questão corrigida
9. Quando finalizar a correção de todas as questões, clique em "Finalizar Correção"

### Financeiro

O módulo financeiro gerencia mensalidades, pagamentos e relatórios financeiros.

#### Planos de Mensalidade

Para acessar os planos de mensalidade (Administrador/Financeiro):
1. No menu lateral, clique em "Financeiro"
2. Selecione "Planos de Mensalidade"

Para criar um novo plano (Administrador/Financeiro):
1. Na página de planos, clique no botão "Novo Plano"
2. Preencha os campos obrigatórios (nome, valor)
3. Defina descontos para pagamento antecipado (opcional)
4. Clique em "Salvar"

#### Mensalidades

Para acessar as mensalidades (Administrador/Financeiro/Aluno):
1. No menu lateral, clique em "Financeiro"
2. Selecione "Mensalidades"

Para gerar mensalidades (Administrador/Financeiro):
1. Na página de mensalidades, clique no botão "Gerar Mensalidades"
2. Selecione o plano de mensalidade
3. Selecione os alunos ou turmas
4. Defina o período (mês/ano)
5. Clique em "Gerar"

#### Pagamentos

Para registrar um pagamento (Administrador/Financeiro):
1. Na página de mensalidades, localize a mensalidade desejada
2. Clique no botão "Registrar Pagamento"
3. Preencha os campos obrigatórios (data, valor, forma de pagamento)
4. Clique em "Salvar"

Para realizar um pagamento (Aluno):
1. No menu lateral, clique em "Financeiro"
2. Selecione "Mensalidades"
3. Localize a mensalidade que deseja pagar
4. Clique no botão "Pagar"
5. Selecione a forma de pagamento (boleto, PIX, cartão de crédito)
6. Siga as instruções na tela para concluir o pagamento

### Biblioteca Digital

O módulo de biblioteca digital gerencia livros e materiais digitais.

#### Livros

Para acessar a biblioteca digital:
1. No menu lateral, clique em "Biblioteca"
2. Selecione "Livros"

Para adicionar um novo livro (Administrador/Coordenador/Professor):
1. Na página de livros, clique no botão "Novo Livro"
2. Preencha os campos obrigatórios (título, autor, disciplina)
3. Faça upload do arquivo PDF
4. Clique em "Salvar"

Para acessar um livro (Aluno):
1. Na página de livros, utilize os filtros para encontrar o livro desejado
2. Clique no título do livro para acessar a página de detalhes
3. Clique no botão "Ler Online" para abrir o livro no navegador
4. Ou clique em "Download" para baixar o arquivo PDF

#### Busca de Materiais

Para buscar materiais na biblioteca:
1. Na página de biblioteca, utilize o campo de busca
2. Digite palavras-chave relacionadas ao material desejado
3. Selecione o tipo de filtro (título, autor, disciplina)
4. Clique em "Buscar"
5. Os resultados serão exibidos abaixo

### Suporte

O módulo de suporte gerencia chamados e atendimento aos usuários.

#### Abrir Chamado

Para abrir um novo chamado (Aluno):
1. No menu lateral, clique em "Suporte"
2. Clique no botão "Novo Chamado"
3. Preencha os campos obrigatórios (título, descrição)
4. Selecione a categoria do chamado
5. Anexe arquivos, se necessário
6. Clique em "Enviar"

#### Atender Chamado

Para atender um chamado (Suporte/Atendente):
1. No menu lateral, clique em "Suporte"
2. Localize o chamado desejado na lista
3. Clique no título do chamado para acessar a página de detalhes
4. Leia a descrição e os detalhes do chamado
5. Clique no botão "Atender"
6. Digite sua resposta no campo de texto
7. Clique em "Enviar Resposta"
8. Se o problema foi resolvido, clique em "Fechar Chamado"

#### Acompanhar Chamado

Para acompanhar um chamado (Aluno):
1. No menu lateral, clique em "Suporte"
2. Localize o chamado desejado na lista
3. Clique no título do chamado para acessar a página de detalhes
4. Verifique o status e as respostas do atendente
5. Para adicionar mais informações, digite no campo de texto
6. Clique em "Enviar Resposta"

## Perguntas Frequentes

### Acesso ao Sistema

**P: Como faço para alterar minha senha?**

R: Para alterar sua senha:
1. Clique no seu nome/foto no canto superior direito
2. Selecione "Minha Conta"
3. Na seção "Segurança", clique em "Alterar Senha"
4. Informe sua senha atual e a nova senha
5. Clique em "Salvar"

**P: O que fazer se eu esquecer minha senha?**

R: Na tela de login, clique em "Esqueci minha senha" e siga as instruções enviadas para seu e-mail.

**P: Posso acessar o sistema pelo celular?**

R: Sim, o sistema é responsivo e pode ser acessado por qualquer dispositivo com navegador web.

### Aulas e Conteúdo

**P: Como sei quais aulas estão disponíveis para mim?**

R: No menu lateral, clique em "Aulas" para ver todas as aulas disponíveis para suas turmas.

**P: Posso baixar as videoaulas para assistir offline?**

R: Não, as videoaulas são transmitidas via streaming e não podem ser baixadas. No entanto, você pode baixar os materiais complementares.

**P: O que fazer se eu não puder participar de uma aula ao vivo?**

R: As aulas ao vivo são gravadas e disponibilizadas posteriormente na seção de videoaulas.

### Avaliações

**P: Como sei quando tenho uma avaliação para fazer?**

R: Você receberá notificações sobre novas avaliações. Além disso, todas as avaliações pendentes aparecem na sua página inicial (Dashboard).

**P: O que acontece se eu não entregar uma avaliação no prazo?**

R: Após o prazo, o sistema não permite mais o envio da avaliação. Entre em contato com seu professor para verificar a possibilidade de entrega com atraso.

**P: Como vejo minhas notas?**

R: No menu lateral, clique em "Acadêmico" e selecione "Notas" para ver seu histórico de avaliações e notas.

### Financeiro

**P: Como gero um boleto para pagamento?**

R: No menu lateral, clique em "Financeiro", selecione a mensalidade desejada e clique em "Gerar Boleto".

**P: Quais formas de pagamento são aceitas?**

R: O sistema aceita pagamento por boleto bancário, PIX e cartão de crédito.

**P: O que fazer se o boleto estiver vencido?**

R: Você pode gerar um novo boleto com a data atualizada na seção "Financeiro".

### Suporte

**P: Quanto tempo leva para meu chamado ser respondido?**

R: O tempo de resposta varia conforme a complexidade do problema, mas geralmente os chamados são respondidos em até 24 horas úteis.

**P: Como sei se meu chamado foi resolvido?**

R: Você receberá uma notificação quando seu chamado for atualizado ou resolvido. Além disso, pode acompanhar o status na seção "Suporte".

**P: Posso reabrir um chamado já fechado?**

R: Sim, na página de detalhes do chamado, clique no botão "Reabrir Chamado" e informe o motivo.

