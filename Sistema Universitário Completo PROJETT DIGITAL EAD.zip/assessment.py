from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.assessment import Assessment, Question, Answer, Grade, db
from src.models.user import User

assessment_bp = Blueprint('assessment', __name__)

# Rotas para Avaliações
@assessment_bp.route('/assessments', methods=['GET'])
@jwt_required()
def get_assessments():
    assessments = Assessment.query.all()
    return jsonify([{
        'id': assessment.id,
        'title': assessment.title,
        'class_id': assessment.class_id,
        'assessment_type': assessment.assessment_type
    } for assessment in assessments]), 200

@assessment_bp.route('/assessments/<int:assessment_id>', methods=['GET'])
@jwt_required()
def get_assessment(assessment_id):
    assessment = Assessment.query.get(assessment_id)
    if not assessment:
        return jsonify({'message': 'Avaliação não encontrada'}), 404
    
    return jsonify({
        'id': assessment.id,
        'title': assessment.title,
        'class_id': assessment.class_id,
        'assessment_type': assessment.assessment_type
    }), 200

@assessment_bp.route('/assessments', methods=['POST'])
@jwt_required()
def create_assessment():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    title = data.get('title')
    class_id = data.get('class_id')
    assessment_type = data.get('assessment_type')
    
    if not title or not class_id or not assessment_type:
        return jsonify({'message': 'Título, ID da turma e tipo da avaliação são obrigatórios'}), 400
    
    new_assessment = Assessment(
        title=title,
        class_id=class_id,
        assessment_type=assessment_type
    )
    
    db.session.add(new_assessment)
    db.session.commit()
    
    return jsonify({'message': 'Avaliação criada com sucesso', 'id': new_assessment.id}), 201

@assessment_bp.route('/assessments/<int:assessment_id>', methods=['PUT'])
@jwt_required()
def update_assessment(assessment_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    assessment = Assessment.query.get(assessment_id)
    if not assessment:
        return jsonify({'message': 'Avaliação não encontrada'}), 404
    
    data = request.get_json()
    assessment.title = data.get('title', assessment.title)
    assessment.class_id = data.get('class_id', assessment.class_id)
    assessment.assessment_type = data.get('assessment_type', assessment.assessment_type)
    
    db.session.commit()
    
    return jsonify({'message': 'Avaliação atualizada com sucesso'}), 200

@assessment_bp.route('/assessments/<int:assessment_id>', methods=['DELETE'])
@jwt_required()
def delete_assessment(assessment_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    assessment = Assessment.query.get(assessment_id)
    if not assessment:
        return jsonify({'message': 'Avaliação não encontrada'}), 404
    
    db.session.delete(assessment)
    db.session.commit()
    
    return jsonify({'message': 'Avaliação excluída com sucesso'}), 200

# Rotas para Questões
@assessment_bp.route('/questions', methods=['GET'])
@jwt_required()
def get_questions():
    assessment_id = request.args.get('assessment_id')
    
    if assessment_id:
        questions = Question.query.filter_by(assessment_id=assessment_id).all()
    else:
        questions = Question.query.all()
    
    return jsonify([{
        'id': question.id,
        'statement': question.statement,
        'question_type': question.question_type,
        'assessment_id': question.assessment_id
    } for question in questions]), 200

@assessment_bp.route('/questions/<int:question_id>', methods=['GET'])
@jwt_required()
def get_question(question_id):
    question = Question.query.get(question_id)
    if not question:
        return jsonify({'message': 'Questão não encontrada'}), 404
    
    return jsonify({
        'id': question.id,
        'statement': question.statement,
        'question_type': question.question_type,
        'assessment_id': question.assessment_id
    }), 200

@assessment_bp.route('/questions', methods=['POST'])
@jwt_required()
def create_question():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    statement = data.get('statement')
    question_type = data.get('question_type')
    assessment_id = data.get('assessment_id')
    
    if not statement or not question_type or not assessment_id:
        return jsonify({'message': 'Enunciado, tipo da questão e ID da avaliação são obrigatórios'}), 400
    
    new_question = Question(
        statement=statement,
        question_type=question_type,
        assessment_id=assessment_id
    )
    
    db.session.add(new_question)
    db.session.commit()
    
    return jsonify({'message': 'Questão criada com sucesso', 'id': new_question.id}), 201

@assessment_bp.route('/questions/<int:question_id>', methods=['PUT'])
@jwt_required()
def update_question(question_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    question = Question.query.get(question_id)
    if not question:
        return jsonify({'message': 'Questão não encontrada'}), 404
    
    data = request.get_json()
    question.statement = data.get('statement', question.statement)
    question.question_type = data.get('question_type', question.question_type)
    question.assessment_id = data.get('assessment_id', question.assessment_id)
    
    db.session.commit()
    
    return jsonify({'message': 'Questão atualizada com sucesso'}), 200

@assessment_bp.route('/questions/<int:question_id>', methods=['DELETE'])
@jwt_required()
def delete_question(question_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    question = Question.query.get(question_id)
    if not question:
        return jsonify({'message': 'Questão não encontrada'}), 404
    
    db.session.delete(question)
    db.session.commit()
    
    return jsonify({'message': 'Questão excluída com sucesso'}), 200

# Rotas para Respostas
@assessment_bp.route('/answers', methods=['GET'])
@jwt_required()
def get_answers():
    student_id = request.args.get('student_id')
    question_id = request.args.get('question_id')
    
    query = Answer.query
    
    if student_id:
        query = query.filter_by(student_id=student_id)
    
    if question_id:
        query = query.filter_by(question_id=question_id)
    
    answers = query.all()
    
    return jsonify([{
        'id': answer.id,
        'student_id': answer.student_id,
        'question_id': answer.question_id,
        'text_answer': answer.text_answer,
        'option_answer': answer.option_answer
    } for answer in answers]), 200

@assessment_bp.route('/answers', methods=['POST'])
@jwt_required()
def create_answer():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    data = request.get_json()
    student_id = data.get('student_id', current_user_id)
    question_id = data.get('question_id')
    text_answer = data.get('text_answer')
    option_answer = data.get('option_answer')
    
    if not question_id:
        return jsonify({'message': 'ID da questão é obrigatório'}), 400
    
    # Verificar se já existe resposta
    existing_answer = Answer.query.filter_by(
        student_id=student_id, 
        question_id=question_id
    ).first()
    
    if existing_answer:
        return jsonify({'message': 'Resposta já existe para esta questão'}), 400
    
    new_answer = Answer(
        student_id=student_id,
        question_id=question_id,
        text_answer=text_answer,
        option_answer=option_answer
    )
    
    db.session.add(new_answer)
    db.session.commit()
    
    return jsonify({'message': 'Resposta criada com sucesso', 'id': new_answer.id}), 201

# Rotas para Notas
@assessment_bp.route('/grades', methods=['GET'])
@jwt_required()
def get_grades():
    student_id = request.args.get('student_id')
    assessment_id = request.args.get('assessment_id')
    
    query = Grade.query
    
    if student_id:
        query = query.filter_by(student_id=student_id)
    
    if assessment_id:
        query = query.filter_by(assessment_id=assessment_id)
    
    grades = query.all()
    
    return jsonify([{
        'id': grade.id,
        'student_id': grade.student_id,
        'assessment_id': grade.assessment_id,
        'grade': grade.grade
    } for grade in grades]), 200

@assessment_bp.route('/grades', methods=['POST'])
@jwt_required()
def create_grade():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    student_id = data.get('student_id')
    assessment_id = data.get('assessment_id')
    grade_value = data.get('grade')
    
    if not student_id or not assessment_id or grade_value is None:
        return jsonify({'message': 'ID do aluno, ID da avaliação e nota são obrigatórios'}), 400
    
    # Verificar se já existe nota
    existing_grade = Grade.query.filter_by(
        student_id=student_id, 
        assessment_id=assessment_id
    ).first()
    
    if existing_grade:
        existing_grade.grade = grade_value
        db.session.commit()
        return jsonify({'message': 'Nota atualizada com sucesso', 'id': existing_grade.id}), 200
    
    new_grade = Grade(
        student_id=student_id,
        assessment_id=assessment_id,
        grade=grade_value
    )
    
    db.session.add(new_grade)
    db.session.commit()
    
    return jsonify({'message': 'Nota criada com sucesso', 'id': new_grade.id}), 201

