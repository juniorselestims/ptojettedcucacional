# Documentação do Sistema PROJETT DIGITAL EAD

## Sumário

1. [Introdução](#introdução)
2. [Arquitetura do Sistema](#arquitetura-do-sistema)
3. [Estrutura do Banco de Dados](#estrutura-do-banco-de-dados)
4. [Backend (API REST)](#backend-api-rest)
5. [Frontend (React)](#frontend-react)
6. [Integrações](#integrações)
7. [Guia de Instalação](#guia-de-instalação)
8. [Guia de Uso](#guia-de-uso)
9. [Manutenção e Suporte](#manutenção-e-suporte)

## Introdução

O PROJETT DIGITAL EAD é um sistema universitário completo para ensino à distância, desenvolvido para atender às necessidades de instituições de ensino superior que oferecem cursos online. O sistema integra funcionalidades acadêmicas, financeiras e administrativas em uma única plataforma.

### Objetivos do Sistema

- Gerenciar cursos, disciplinas, turmas e matrículas
- Disponibilizar aulas online (gravadas e ao vivo)
- Criar e gerenciar avaliações
- Controlar pagamentos e mensalidades
- Oferecer biblioteca digital
- Fornecer suporte aos alunos

### Usuários do Sistema

O sistema possui seis tipos de usuários, cada um com permissões específicas:

1. **Administrador**: Acesso completo a todas as funcionalidades do sistema
2. **Coordenador de Curso**: Gerencia turmas, disciplinas e professores
3. **Professor**: Cria aulas, disponibiliza materiais e corrige atividades
4. **Aluno**: Acessa aulas, realiza atividades, acompanha notas e boletos
5. **Financeiro**: Emite cobranças, controla pagamentos, gera relatórios
6. **Suporte/Atendente**: Tira dúvidas, responde chamados dos alunos

## Arquitetura do Sistema

O PROJETT DIGITAL EAD foi desenvolvido utilizando uma arquitetura cliente-servidor, com separação clara entre frontend e backend:

### Visão Geral

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Cliente   │     │   Servidor  │     │   Banco de  │
│  (Browser)  │◄───►│   (API)     │◄───►│    Dados    │
└─────────────┘     └─────────────┘     └─────────────┘
```

### Tecnologias Utilizadas

- **Frontend**: React.js, TailwindCSS
- **Backend**: Flask (Python)
- **Banco de Dados**: SQLite (desenvolvimento), PostgreSQL (produção)
- **Autenticação**: JWT (JSON Web Tokens)
- **Integrações**: Zoom (aulas ao vivo), Mercado Pago (pagamentos)

### Componentes Principais

1. **API REST**: Interface para comunicação entre frontend e backend
2. **Autenticação e Autorização**: Controle de acesso baseado em perfis
3. **Serviços de Integração**: Conexão com serviços externos (Zoom, gateway de pagamento)
4. **Sistema de Notificações**: Envio de e-mails e mensagens de WhatsApp

## Estrutura do Banco de Dados

O banco de dados do sistema é composto por diversas tabelas que representam as entidades principais do sistema e seus relacionamentos.

### Diagrama ER Simplificado

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│    Users    │     │   Courses   │     │ Disciplines │
└─────────────┘     └─────────────┘     └─────────────┘
       ▲ ▲                 ▲                   ▲
       │ │                 │                   │
       │ └─────────┐       │                   │
       │           │       │                   │
┌─────────────┐   ┌─────────────┐     ┌─────────────┐
│ Enrollments │   │   Classes   │◄────┤    Books    │
└─────────────┘   └─────────────┘     └─────────────┘
                         ▲
                         │
       ┌────────────────┬┴───────────────┐
       │                │                │
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│   Lessons   │  │ Assessments │  │   Invoices  │
└─────────────┘  └─────────────┘  └─────────────┘
       ▲                ▲
       │                │
┌─────────────┐  ┌─────────────┐
│  Materials  │  │  Questions  │
└─────────────┘  └─────────────┘
                        ▲
                        │
                 ┌─────────────┐
                 │   Answers   │
                 └─────────────┘
```

### Principais Entidades

1. **Users**: Armazena informações de todos os usuários do sistema
2. **Courses**: Cursos oferecidos pela instituição
3. **Disciplines**: Disciplinas que compõem os cursos
4. **Classes**: Turmas de cada disciplina
5. **Enrollments**: Matrículas dos alunos nas turmas
6. **Lessons**: Aulas (vídeo ou ao vivo)
7. **Materials**: Materiais complementares das aulas
8. **Assessments**: Avaliações
9. **Questions**: Questões das avaliações
10. **Answers**: Respostas dos alunos às questões
11. **Invoices**: Faturas e mensalidades
12. **Books**: Livros e materiais da biblioteca digital

## Backend (API REST)

O backend do sistema foi desenvolvido em Python utilizando o framework Flask, seguindo os princípios de uma API REST.

### Estrutura de Diretórios

```
backend/
├── src/
│   ├── main.py                # Ponto de entrada da aplicação
│   ├── models/                # Modelos de dados
│   │   ├── user.py
│   │   ├── course.py
│   │   ├── ...
│   ├── routes/                # Rotas da API
│   │   ├── auth.py
│   │   ├── course.py
│   │   ├── ...
│   ├── services/              # Serviços de integração
│   │   ├── zoom_service.py
│   │   ├── payment_service.py
│   │   ├── notification_service.py
│   ├── database/              # Arquivos do banco de dados
│   └── static/                # Arquivos estáticos
└── venv/                      # Ambiente virtual Python
```

### Endpoints da API

#### Autenticação

- `POST /api/auth/login`: Autenticação de usuários
- `POST /api/auth/register`: Registro de novos usuários
- `POST /api/auth/refresh`: Renovação de token JWT

#### Acadêmico

- `GET /api/courses`: Lista de cursos
- `GET /api/disciplines`: Lista de disciplinas
- `GET /api/classes`: Lista de turmas
- `GET /api/enrollments`: Lista de matrículas

#### Aulas

- `GET /api/lessons`: Lista de aulas
- `GET /api/lessons/{id}`: Detalhes de uma aula
- `GET /api/lessons/{id}/materials`: Materiais de uma aula

#### Avaliações

- `GET /api/assessments`: Lista de avaliações
- `GET /api/assessments/{id}`: Detalhes de uma avaliação
- `GET /api/assessments/{id}/questions`: Questões de uma avaliação

#### Financeiro

- `GET /api/invoices`: Lista de faturas
- `GET /api/tuition-plans`: Lista de planos de mensalidade

#### Biblioteca

- `GET /api/books`: Lista de livros

#### Suporte

- `GET /api/tickets`: Lista de chamados
- `POST /api/tickets`: Criar novo chamado

#### Integrações

- `POST /api/zoom/meetings`: Criar reunião no Zoom
- `POST /api/payment/boleto/{invoice_id}`: Gerar boleto
- `POST /api/payment/pix/{invoice_id}`: Gerar PIX
- `POST /api/notification/notify-lesson/{lesson_id}`: Notificar sobre nova aula

### Autenticação e Autorização

O sistema utiliza JWT (JSON Web Tokens) para autenticação. Cada requisição à API (exceto login e registro) deve incluir um token válido no cabeçalho de autorização.

```python
# Exemplo de proteção de rota
@course_bp.route('/courses', methods=['POST'])
@jwt_required()
def create_course():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    # Lógica para criar curso
```

## Frontend (React)

O frontend do sistema foi desenvolvido em React.js, utilizando TailwindCSS para estilização e diversos componentes da biblioteca shadcn/ui.

### Estrutura de Diretórios

```
frontend/
├── public/                    # Arquivos públicos
├── src/
│   ├── App.jsx                # Componente principal
│   ├── contexts/              # Contextos React
│   │   ├── AuthContext.jsx    # Contexto de autenticação
│   ├── layouts/               # Layouts da aplicação
│   │   ├── AuthLayout.jsx     # Layout para páginas de autenticação
│   │   ├── DashboardLayout.jsx # Layout para páginas do dashboard
│   ├── pages/                 # Páginas da aplicação
│   │   ├── auth/              # Páginas de autenticação
│   │   ├── dashboard/         # Páginas do dashboard
│   │   ├── academic/          # Páginas acadêmicas
│   │   ├── lessons/           # Páginas de aulas
│   │   ├── assessments/       # Páginas de avaliações
│   │   ├── financial/         # Páginas financeiras
│   │   ├── library/           # Páginas da biblioteca
│   ├── components/            # Componentes reutilizáveis
│   └── index.jsx              # Ponto de entrada
└── node_modules/              # Dependências
```

### Principais Componentes

1. **AuthContext**: Gerencia o estado de autenticação do usuário
2. **DashboardLayout**: Layout comum para todas as páginas após login
3. **Páginas Principais**:
   - Login e Registro
   - Dashboard (visão geral)
   - Cursos, Disciplinas, Turmas
   - Aulas (videoaulas e aulas ao vivo)
   - Avaliações
   - Financeiro (boletos e mensalidades)
   - Biblioteca Digital

### Rotas

O sistema utiliza o React Router para navegação entre páginas:

```jsx
<Routes>
  {/* Rotas públicas */}
  <Route path="/login" element={<Login />} />
  <Route path="/register" element={<Register />} />
  
  {/* Rotas protegidas */}
  <Route path="/" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
    <Route index element={<Dashboard />} />
    <Route path="courses" element={<Courses />} />
    <Route path="disciplines" element={<Disciplines />} />
    <Route path="classes" element={<Classes />} />
    <Route path="enrollments" element={<Enrollments />} />
    <Route path="lessons" element={<Lessons />} />
    <Route path="lessons/:id" element={<LessonView />} />
    <Route path="live-class/:id" element={<LiveClass />} />
    <Route path="assessments" element={<Assessments />} />
    <Route path="invoices" element={<Invoices />} />
    <Route path="books" element={<Books />} />
  </Route>
</Routes>
```

### Autenticação no Frontend

O frontend utiliza o contexto de autenticação para gerenciar o estado do usuário logado:

```jsx
// Exemplo simplificado do AuthContext
export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Verificar se há um token no localStorage
    const token = localStorage.getItem('token');
    if (token) {
      // Verificar se o token é válido
      axios.get('/api/auth/verify', {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(response => {
        setCurrentUser(response.data.user);
      })
      .catch(() => {
        localStorage.removeItem('token');
      })
      .finally(() => {
        setLoading(false);
      });
    } else {
      setLoading(false);
    }
  }, []);
  
  const login = async (email, password) => {
    // Lógica de login
  };
  
  const logout = () => {
    // Lógica de logout
  };
  
  return (
    <AuthContext.Provider value={{ currentUser, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};
```

## Integrações

O sistema integra-se com serviços externos para fornecer funcionalidades avançadas.

### Zoom (Aulas ao Vivo)

A integração com o Zoom permite a criação e gerenciamento de aulas ao vivo:

```python
# Exemplo simplificado do serviço de integração com Zoom
class ZoomService:
    def __init__(self):
        self.api_key = os.getenv('ZOOM_API_KEY')
        self.api_secret = os.getenv('ZOOM_API_SECRET')
        self.base_url = 'https://api.zoom.us/v2'
        
    def create_meeting(self, topic, start_time, duration, description=None):
        # Lógica para criar reunião no Zoom
        # Retorna dados da reunião criada
```

### Gateway de Pagamento

A integração com gateway de pagamento permite a geração de boletos, PIX e processamento de cartão de crédito:

```python
# Exemplo simplificado do serviço de pagamento
class PaymentService:
    def __init__(self, provider='mercado_pago'):
        self.provider = provider
        self.api_key = os.getenv('MERCADO_PAGO_API_KEY')
        
    def generate_boleto(self, invoice):
        # Lógica para gerar boleto
        # Retorna dados do boleto gerado
        
    def generate_pix(self, invoice):
        # Lógica para gerar PIX
        # Retorna dados do PIX gerado
```

### Sistema de Notificações

O sistema de notificações permite o envio de e-mails e mensagens de WhatsApp:

```python
# Exemplo simplificado do serviço de notificações
class NotificationService:
    def __init__(self):
        self.email_sender = os.getenv('EMAIL_SENDER')
        self.email_password = os.getenv('EMAIL_PASSWORD')
        self.whatsapp_api_key = os.getenv('WHATSAPP_API_KEY')
        
    def send_email(self, recipient, subject, message, html_message=None):
        # Lógica para enviar e-mail
        
    def send_whatsapp(self, phone_number, message):
        # Lógica para enviar mensagem de WhatsApp
```

## Guia de Instalação

### Requisitos

- Python 3.8+
- Node.js 14+
- PostgreSQL (para produção)

### Instalação do Backend

1. Clone o repositório:
   ```
   git clone https://github.com/projett-digital/ead-system.git
   cd ead-system
   ```

2. Configure o ambiente virtual Python:
   ```
   cd backend
   python -m venv venv
   source venv/bin/activate  # No Windows: venv\Scripts\activate
   ```

3. Instale as dependências:
   ```
   pip install -r requirements.txt
   ```

4. Configure as variáveis de ambiente:
   ```
   cp .env.example .env
   # Edite o arquivo .env com suas configurações
   ```

5. Inicialize o banco de dados:
   ```
   flask db init
   flask db migrate
   flask db upgrade
   ```

6. Execute o servidor:
   ```
   python src/main.py
   ```

### Instalação do Frontend

1. Navegue até a pasta do frontend:
   ```
   cd ../frontend
   ```

2. Instale as dependências:
   ```
   npm install
   ```

3. Configure as variáveis de ambiente:
   ```
   cp .env.example .env
   # Edite o arquivo .env com suas configurações
   ```

4. Execute o servidor de desenvolvimento:
   ```
   npm run dev
   ```

### Configuração para Produção

Para ambiente de produção, recomenda-se:

1. Utilizar PostgreSQL como banco de dados
2. Configurar um servidor web como Nginx ou Apache
3. Utilizar Gunicorn para servir a aplicação Flask
4. Configurar HTTPS com certificado SSL
5. Fazer build otimizado do frontend:
   ```
   npm run build
   ```

## Guia de Uso

### Acesso ao Sistema

1. Acesse o sistema pelo navegador: `http://localhost:5173` (desenvolvimento) ou pelo domínio configurado (produção)
2. Faça login com as credenciais fornecidas pelo administrador
3. Navegue pelo menu lateral para acessar as diferentes funcionalidades

### Funcionalidades por Perfil

#### Administrador

- Gerenciar usuários (criar, editar, excluir)
- Gerenciar cursos e disciplinas
- Acessar relatórios gerenciais
- Configurar parâmetros do sistema

#### Coordenador de Curso

- Gerenciar disciplinas do seu curso
- Criar e gerenciar turmas
- Atribuir professores às turmas
- Acompanhar desempenho dos alunos

#### Professor

- Criar aulas (vídeo ou ao vivo)
- Disponibilizar materiais
- Criar avaliações
- Corrigir atividades e atribuir notas

#### Aluno

- Acessar aulas e materiais
- Realizar avaliações
- Visualizar notas e histórico
- Acessar biblioteca digital
- Visualizar e pagar mensalidades

#### Financeiro

- Gerenciar planos de mensalidade
- Emitir boletos e faturas
- Controlar pagamentos
- Gerar relatórios financeiros

#### Suporte/Atendente

- Atender chamados dos alunos
- Responder dúvidas
- Acompanhar tickets abertos

## Manutenção e Suporte

### Backup do Banco de Dados

Recomenda-se realizar backups diários do banco de dados:

```bash
# Exemplo para PostgreSQL
pg_dump -U username -d database_name > backup_$(date +%Y%m%d).sql
```

### Logs do Sistema

Os logs do sistema são armazenados em:

- Backend: `/var/log/projett-ead/backend.log`
- Frontend: `/var/log/projett-ead/frontend.log`

### Atualizações

Para atualizar o sistema:

1. Faça backup do banco de dados
2. Atualize o código-fonte:
   ```
   git pull origin main
   ```
3. Atualize as dependências:
   ```
   # Backend
   cd backend
   source venv/bin/activate
   pip install -r requirements.txt
   
   # Frontend
   cd ../frontend
   npm install
   ```
4. Aplique migrações do banco de dados:
   ```
   cd backend
   flask db upgrade
   ```
5. Reinicie os serviços

### Contato para Suporte

Para suporte técnico, entre em contato:

- E-mail: suporte@projettdigital.com.br
- Telefone: (XX) XXXX-XXXX
- Horário de atendimento: Segunda a Sexta, das 8h às 18h

