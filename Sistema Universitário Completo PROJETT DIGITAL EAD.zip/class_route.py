from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.class_model import Class, db
from src.models.user import User

class_bp = Blueprint('class', __name__)

@class_bp.route('/classes', methods=['GET'])
@jwt_required()
def get_classes():
    classes = Class.query.all()
    return jsonify([{
        'id': class_obj.id,
        'name': class_obj.name,
        'discipline_id': class_obj.discipline_id,
        'professor_id': class_obj.professor_id,
        'academic_year': class_obj.academic_year
    } for class_obj in classes]), 200

@class_bp.route('/classes/<int:class_id>', methods=['GET'])
@jwt_required()
def get_class(class_id):
    class_obj = Class.query.get(class_id)
    if not class_obj:
        return jsonify({'message': 'Turma não encontrada'}), 404
    
    return jsonify({
        'id': class_obj.id,
        'name': class_obj.name,
        'discipline_id': class_obj.discipline_id,
        'professor_id': class_obj.professor_id,
        'academic_year': class_obj.academic_year
    }), 200

@class_bp.route('/classes', methods=['POST'])
@jwt_required()
def create_class():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    name = data.get('name')
    discipline_id = data.get('discipline_id')
    professor_id = data.get('professor_id')
    academic_year = data.get('academic_year')
    
    if not name or not discipline_id:
        return jsonify({'message': 'Nome da turma e ID da disciplina são obrigatórios'}), 400
    
    new_class = Class(
        name=name,
        discipline_id=discipline_id,
        professor_id=professor_id,
        academic_year=academic_year
    )
    
    db.session.add(new_class)
    db.session.commit()
    
    return jsonify({'message': 'Turma criada com sucesso', 'id': new_class.id}), 201

@class_bp.route('/classes/<int:class_id>', methods=['PUT'])
@jwt_required()
def update_class(class_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    class_obj = Class.query.get(class_id)
    if not class_obj:
        return jsonify({'message': 'Turma não encontrada'}), 404
    
    data = request.get_json()
    class_obj.name = data.get('name', class_obj.name)
    class_obj.discipline_id = data.get('discipline_id', class_obj.discipline_id)
    class_obj.professor_id = data.get('professor_id', class_obj.professor_id)
    class_obj.academic_year = data.get('academic_year', class_obj.academic_year)
    
    db.session.commit()
    
    return jsonify({'message': 'Turma atualizada com sucesso'}), 200

@class_bp.route('/classes/<int:class_id>', methods=['DELETE'])
@jwt_required()
def delete_class(class_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type != 'Admin':
        return jsonify({'message': 'Acesso negado'}), 403
    
    class_obj = Class.query.get(class_id)
    if not class_obj:
        return jsonify({'message': 'Turma não encontrada'}), 404
    
    db.session.delete(class_obj)
    db.session.commit()
    
    return jsonify({'message': 'Turma excluída com sucesso'}), 200

