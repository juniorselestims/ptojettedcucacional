import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import './App.css';

// Layouts
import DashboardLayout from './layouts/DashboardLayout';
import AuthLayout from './layouts/AuthLayout';

// Páginas de autenticação
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

// Páginas do dashboard
import Dashboard from './pages/dashboard/Dashboard';

// Páginas acadêmicas
import Courses from './pages/academic/Courses';
import Disciplines from './pages/academic/Disciplines';
import Classes from './pages/academic/Classes';
import Enrollments from './pages/academic/Enrollments';

// Páginas de aulas
import Lessons from './pages/lessons/Lessons';
import LessonView from './pages/lessons/LessonView';
import LiveClass from './pages/lessons/LiveClass';

// Páginas de avaliações
import Assessments from './pages/assessments/Assessments';
import AssessmentView from './pages/assessments/AssessmentView';
import Grades from './pages/assessments/Grades';

// Páginas financeiras
import Invoices from './pages/financial/Invoices';
import TuitionPlans from './pages/financial/TuitionPlans';

// Páginas da biblioteca
import Books from './pages/library/Books';
import BookView from './pages/library/BookView';

// Páginas de suporte
import Tickets from './pages/support/Tickets';
import TicketView from './pages/support/TicketView';

// Páginas de usuários
import Users from './pages/users/Users';
import Profile from './pages/users/Profile';

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          {/* Rotas de autenticação */}
          <Route element={<AuthLayout />}>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Route>

          {/* Rotas do dashboard */}
          <Route element={<DashboardLayout />}>
            <Route path="/" element={<Dashboard />} />
            
            {/* Rotas acadêmicas */}
            <Route path="/courses" element={<Courses />} />
            <Route path="/disciplines" element={<Disciplines />} />
            <Route path="/classes" element={<Classes />} />
            <Route path="/enrollments" element={<Enrollments />} />
            
            {/* Rotas de aulas */}
            <Route path="/lessons" element={<Lessons />} />
            <Route path="/lessons/:id" element={<LessonView />} />
            <Route path="/live-class/:id" element={<LiveClass />} />
            
            {/* Rotas de avaliações */}
            <Route path="/assessments" element={<Assessments />} />
            <Route path="/assessments/:id" element={<AssessmentView />} />
            <Route path="/grades" element={<Grades />} />
            
            {/* Rotas financeiras */}
            <Route path="/invoices" element={<Invoices />} />
            <Route path="/tuition-plans" element={<TuitionPlans />} />
            
            {/* Rotas da biblioteca */}
            <Route path="/books" element={<Books />} />
            <Route path="/books/:id" element={<BookView />} />
            
            {/* Rotas de suporte */}
            <Route path="/tickets" element={<Tickets />} />
            <Route path="/tickets/:id" element={<TicketView />} />
            
            {/* Rotas de usuários */}
            <Route path="/users" element={<Users />} />
            <Route path="/profile" element={<Profile />} />
          </Route>
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;

