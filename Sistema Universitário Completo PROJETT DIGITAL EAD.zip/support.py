from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.support import Ticket, db
from src.models.user import User

support_bp = Blueprint('support', __name__)

@support_bp.route('/tickets', methods=['GET'])
@jwt_required()
def get_tickets():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    status = request.args.get('status')
    
    query = Ticket.query
    
    # Filtrar por status se fornecido
    if status:
        query = query.filter_by(status=status)
    
    # Alunos só podem ver seus próprios chamados
    if user.user_type == 'Aluno':
        tickets = query.filter_by(student_id=current_user_id).all()
    # Atendentes só podem ver chamados atribuídos a eles ou não atribuídos
    elif user.user_type == 'Suporte':
        tickets = query.filter((Ticket.attendant_id == current_user_id) | 
                              (Ticket.attendant_id == None)).all()
    # Admin e outros podem ver todos os chamados
    else:
        tickets = query.all()
    
    return jsonify([{
        'id': ticket.id,
        'student_id': ticket.student_id,
        'attendant_id': ticket.attendant_id,
        'title': ticket.title,
        'description': ticket.description,
        'status': ticket.status
    } for ticket in tickets]), 200

@support_bp.route('/tickets/<int:ticket_id>', methods=['GET'])
@jwt_required()
def get_ticket(ticket_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    ticket = Ticket.query.get(ticket_id)
    if not ticket:
        return jsonify({'message': 'Chamado não encontrado'}), 404
    
    # Verificar permissões
    if user.user_type == 'Aluno' and ticket.student_id != current_user_id:
        return jsonify({'message': 'Acesso negado'}), 403
    
    if user.user_type == 'Suporte' and ticket.attendant_id != current_user_id and ticket.attendant_id is not None:
        return jsonify({'message': 'Acesso negado'}), 403
    
    return jsonify({
        'id': ticket.id,
        'student_id': ticket.student_id,
        'attendant_id': ticket.attendant_id,
        'title': ticket.title,
        'description': ticket.description,
        'status': ticket.status
    }), 200

@support_bp.route('/tickets', methods=['POST'])
@jwt_required()
def create_ticket():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    data = request.get_json()
    title = data.get('title')
    description = data.get('description')
    
    if not title or not description:
        return jsonify({'message': 'Título e descrição são obrigatórios'}), 400
    
    # Se for aluno, o student_id é o próprio usuário
    student_id = current_user_id if user.user_type == 'Aluno' else data.get('student_id')
    
    if not student_id:
        return jsonify({'message': 'ID do aluno é obrigatório'}), 400
    
    new_ticket = Ticket(
        student_id=student_id,
        attendant_id=None,  # Inicialmente não atribuído
        title=title,
        description=description,
        status='Aberto'
    )
    
    db.session.add(new_ticket)
    db.session.commit()
    
    return jsonify({'message': 'Chamado criado com sucesso', 'id': new_ticket.id}), 201

@support_bp.route('/tickets/<int:ticket_id>', methods=['PUT'])
@jwt_required()
def update_ticket(ticket_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    ticket = Ticket.query.get(ticket_id)
    if not ticket:
        return jsonify({'message': 'Chamado não encontrado'}), 404
    
    # Verificar permissões
    if user.user_type == 'Aluno' and ticket.student_id != current_user_id:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    
    # Alunos só podem atualizar título e descrição de seus próprios chamados
    if user.user_type == 'Aluno':
        ticket.title = data.get('title', ticket.title)
        ticket.description = data.get('description', ticket.description)
    # Atendentes e admin podem atualizar todos os campos
    else:
        ticket.title = data.get('title', ticket.title)
        ticket.description = data.get('description', ticket.description)
        ticket.status = data.get('status', ticket.status)
        
        # Atribuir chamado a um atendente
        attendant_id = data.get('attendant_id')
        if attendant_id:
            attendant = User.query.get(attendant_id)
            if not attendant or attendant.user_type != 'Suporte':
                return jsonify({'message': 'Atendente inválido'}), 400
            ticket.attendant_id = attendant_id
    
    db.session.commit()
    
    return jsonify({'message': 'Chamado atualizado com sucesso'}), 200

@support_bp.route('/tickets/<int:ticket_id>', methods=['DELETE'])
@jwt_required()
def delete_ticket(ticket_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Suporte']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    ticket = Ticket.query.get(ticket_id)
    if not ticket:
        return jsonify({'message': 'Chamado não encontrado'}), 404
    
    db.session.delete(ticket)
    db.session.commit()
    
    return jsonify({'message': 'Chamado excluído com sucesso'}), 200

