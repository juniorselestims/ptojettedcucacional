from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.enrollment import Enrollment, db
from src.models.user import User
from datetime import datetime

enrollment_bp = Blueprint('enrollment', __name__)

@enrollment_bp.route('/enrollments', methods=['GET'])
@jwt_required()
def get_enrollments():
    enrollments = Enrollment.query.all()
    return jsonify([{
        'id': enrollment.id,
        'student_id': enrollment.student_id,
        'class_id': enrollment.class_id,
        'enrollment_date': enrollment.enrollment_date.isoformat() if enrollment.enrollment_date else None
    } for enrollment in enrollments]), 200

@enrollment_bp.route('/enrollments/<int:enrollment_id>', methods=['GET'])
@jwt_required()
def get_enrollment(enrollment_id):
    enrollment = Enrollment.query.get(enrollment_id)
    if not enrollment:
        return jsonify({'message': 'Matrícula não encontrada'}), 404
    
    return jsonify({
        'id': enrollment.id,
        'student_id': enrollment.student_id,
        'class_id': enrollment.class_id,
        'enrollment_date': enrollment.enrollment_date.isoformat() if enrollment.enrollment_date else None
    }), 200

@enrollment_bp.route('/enrollments', methods=['POST'])
@jwt_required()
def create_enrollment():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    student_id = data.get('student_id')
    class_id = data.get('class_id')
    
    if not student_id or not class_id:
        return jsonify({'message': 'ID do aluno e ID da turma são obrigatórios'}), 400
    
    # Verificar se já existe matrícula
    existing_enrollment = Enrollment.query.filter_by(
        student_id=student_id, 
        class_id=class_id
    ).first()
    
    if existing_enrollment:
        return jsonify({'message': 'Aluno já matriculado nesta turma'}), 400
    
    new_enrollment = Enrollment(
        student_id=student_id,
        class_id=class_id,
        enrollment_date=datetime.utcnow()
    )
    
    db.session.add(new_enrollment)
    db.session.commit()
    
    return jsonify({'message': 'Matrícula criada com sucesso', 'id': new_enrollment.id}), 201

@enrollment_bp.route('/enrollments/<int:enrollment_id>', methods=['DELETE'])
@jwt_required()
def delete_enrollment(enrollment_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    enrollment = Enrollment.query.get(enrollment_id)
    if not enrollment:
        return jsonify({'message': 'Matrícula não encontrada'}), 404
    
    db.session.delete(enrollment)
    db.session.commit()
    
    return jsonify({'message': 'Matrícula excluída com sucesso'}), 200

