# Endpoints da API REST - PROJETT DIGITAL EAD

## 1. Autenticação e Autorização

*   **POST /api/auth/login**
    *   Autentica um usuário e retorna um token JWT.
*   **POST /api/auth/register**
    *   Registra um novo usuário.
*   **GET /api/auth/me**
    *   Retorna os dados do usuário autenticado.

## 2. Gestão de Usuários (Admin)

*   **GET /api/users**
    *   Lista todos os usuários.
*   **GET /api/users/:id**
    *   Retorna um usuário específico.
*   **POST /api/users**
    *   Cria um novo usuário.
*   **PUT /api/users/:id**
    *   Atualiza um usuário existente.
*   **DELETE /api/users/:id**
    *   Exclui um usuário.

## 3. Gestão Acadêmica

### Cursos
*   **GET /api/courses**
    *   Lista todos os cursos.
*   **GET /api/courses/:id**
    *   Retorna um curso específico.
*   **POST /api/courses**
    *   Cria um novo curso.
*   **PUT /api/courses/:id**
    *   Atualiza um curso existente.
*   **DELETE /api/courses/:id**
    *   Exclui um curso.

### Disciplinas
*   **GET /api/disciplines**
    *   Lista todas as disciplinas.
*   **GET /api/disciplines/:id**
    *   Retorna uma disciplina específica.
*   **POST /api/disciplines**
    *   Cria uma nova disciplina.
*   **PUT /api/disciplines/:id**
    *   Atualiza uma disciplina existente.
*   **DELETE /api/disciplines/:id**
    *   Exclui uma disciplina.

### Turmas
*   **GET /api/classes**
    *   Lista todas as turmas.
*   **GET /api/classes/:id**
    *   Retorna uma turma específica.
*   **POST /api/classes**
    *   Cria uma nova turma.
*   **PUT /api/classes/:id**
    *   Atualiza uma turma existente.
*   **DELETE /api/classes/:id**
    *   Exclui uma turma.

### Matrículas
*   **GET /api/enrollments**
    *   Lista todas as matrículas.
*   **GET /api/enrollments/:id**
    *   Retorna uma matrícula específica.
*   **POST /api/enrollments**
    *   Cria uma nova matrícula.
*   **DELETE /api/enrollments/:id**
    *   Exclui uma matrícula.

### Notas
*   **GET /api/grades**
    *   Lista todas as notas.
*   **GET /api/grades/:id**
    *   Retorna uma nota específica.
*   **POST /api/grades**
    *   Cria uma nova nota.
*   **PUT /api/grades/:id**
    *   Atualiza uma nota existente.
*   **DELETE /api/grades/:id**
    *   Exclui uma nota.

### Frequência
*   **GET /api/attendance**
    *   Lista todas as frequências.
*   **GET /api/attendance/:id**
    *   Retorna uma frequência específica.
*   **POST /api/attendance**
    *   Cria um novo registro de frequência.
*   **PUT /api/attendance/:id**
    *   Atualiza um registro de frequência existente.
*   **DELETE /api/attendance/:id**
    *   Exclui um registro de frequência.

## 4. Aulas Online

### Aulas
*   **GET /api/lessons**
    *   Lista todas as aulas.
*   **GET /api/lessons/:id**
    *   Retorna uma aula específica.
*   **POST /api/lessons**
    *   Cria uma nova aula.
*   **PUT /api/lessons/:id**
    *   Atualiza uma aula existente.
*   **DELETE /api/lessons/:id**
    *   Exclui uma aula.

### Materiais
*   **GET /api/materials**
    *   Lista todos os materiais.
*   **GET /api/materials/:id**
    *   Retorna um material específico.
*   **POST /api/materials**
    *   Cria um novo material.
*   **PUT /api/materials/:id**
    *   Atualiza um material existente.
*   **DELETE /api/materials/:id**
    *   Exclui um material.

## 5. Avaliações

### Avaliações
*   **GET /api/assessments**
    *   Lista todas as avaliações.
*   **GET /api/assessments/:id**
    *   Retorna uma avaliação específica.
*   **POST /api/assessments**
    *   Cria uma nova avaliação.
*   **PUT /api/assessments/:id**
    *   Atualiza uma avaliação existente.
*   **DELETE /api/assessments/:id**
    *   Exclui uma avaliação.

### Questões
*   **GET /api/questions**
    *   Lista todas as questões.
*   **GET /api/questions/:id**
    *   Retorna uma questão específica.
*   **POST /api/questions**
    *   Cria uma nova questão.
*   **PUT /api/questions/:id**
    *   Atualiza uma questão existente.
*   **DELETE /api/questions/:id**
    *   Exclui uma questão.

### Respostas
*   **GET /api/answers**
    *   Lista todas as respostas.
*   **GET /api/answers/:id**
    *   Retorna uma resposta específica.
*   **POST /api/answers**
    *   Cria uma nova resposta.
*   **PUT /api/answers/:id**
    *   Atualiza uma resposta existente.
*   **DELETE /api/answers/:id**
    *   Exclui uma resposta.

## 6. Financeiro

### Planos de Mensalidades
*   **GET /api/tuition-plans**
    *   Lista todos os planos de mensalidades.
*   **GET /api/tuition-plans/:id**
    *   Retorna um plano de mensalidade específico.
*   **POST /api/tuition-plans**
    *   Cria um novo plano de mensalidade.
*   **PUT /api/tuition-plans/:id**
    *   Atualiza um plano de mensalidade existente.
*   **DELETE /api/tuition-plans/:id**
    *   Exclui um plano de mensalidade.

### Boletos
*   **GET /api/invoices**
    *   Lista todos os boletos.
*   **GET /api/invoices/:id**
    *   Retorna um boleto específico.
*   **POST /api/invoices**
    *   Cria um novo boleto.
*   **PUT /api/invoices/:id**
    *   Atualiza um boleto existente.
*   **DELETE /api/invoices/:id**
    *   Exclui um boleto.

## 7. Biblioteca Digital

### Livros
*   **GET /api/books**
    *   Lista todos os livros.
*   **GET /api/books/:id**
    *   Retorna um livro específico.
*   **POST /api/books**
    *   Cria um novo livro.
*   **PUT /api/books/:id**
    *   Atualiza um livro existente.
*   **DELETE /api/books/:id**
    *   Exclui um livro.

## 8. Suporte

### Chamados
*   **GET /api/tickets**
    *   Lista todos os chamados.
*   **GET /api/tickets/:id**
    *   Retorna um chamado específico.
*   **POST /api/tickets**
    *   Cria um novo chamado.
*   **PUT /api/tickets/:id**
    *   Atualiza um chamado existente.
*   **DELETE /api/tickets/:id**
    *   Exclui um chamado.

