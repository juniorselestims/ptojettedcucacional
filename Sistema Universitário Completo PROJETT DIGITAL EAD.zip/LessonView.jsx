import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, ArrowLeft, FileText, Download, MessageSquare } from 'lucide-react';

const LessonView = () => {
  const { id } = useParams();
  const { currentUser } = useAuth();
  const [lesson, setLesson] = useState(null);
  const [materials, setMaterials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    fetchLesson();
    fetchMaterials();
    fetchComments();
  }, [id]);

  const fetchLesson = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`/api/lessons/${id}`);
      setLesson(response.data);
    } catch (error) {
      console.error('Erro ao buscar aula:', error);
      setError('Não foi possível carregar a aula. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchMaterials = async () => {
    try {
      const response = await axios.get(`/api/lessons/${id}/materials`);
      setMaterials(response.data);
    } catch (error) {
      console.error('Erro ao buscar materiais:', error);
    }
  };

  const fetchComments = async () => {
    try {
      // Simulando busca de comentários, já que não temos essa funcionalidade no backend ainda
      setComments([
        {
          id: 1,
          user_name: 'João Silva',
          user_type: 'Aluno',
          content: 'Excelente aula! Consegui entender bem o conteúdo.',
          created_at: '2025-08-15T14:30:00'
        },
        {
          id: 2,
          user_name: 'Maria Oliveira',
          user_type: 'Professor',
          content: 'Obrigado pelo feedback! Se tiverem dúvidas, podem perguntar aqui.',
          created_at: '2025-08-15T15:45:00'
        }
      ]);
    } catch (error) {
      console.error('Erro ao buscar comentários:', error);
    }
  };

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    
    if (!newComment.trim()) return;
    
    // Simulando envio de comentário
    const comment = {
      id: comments.length + 1,
      user_name: currentUser.name,
      user_type: currentUser.user_type,
      content: newComment,
      created_at: new Date().toISOString()
    };
    
    setComments([...comments, comment]);
    setNewComment('');
  };

  const renderVideoPlayer = () => {
    if (!lesson || !lesson.video_url) return null;
    
    // Extrair ID do vídeo do YouTube
    let videoId = '';
    if (lesson.video_url.includes('youtube.com')) {
      const url = new URL(lesson.video_url);
      videoId = url.searchParams.get('v');
    } else if (lesson.video_url.includes('youtu.be')) {
      videoId = lesson.video_url.split('/').pop();
    }
    
    if (!videoId) return <p>Formato de URL de vídeo não suportado.</p>;
    
    return (
      <div className="aspect-video">
        <iframe
          width="100%"
          height="100%"
          src={`https://www.youtube.com/embed/${videoId}`}
          title={lesson.title}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
      </div>
    );
  };

  const renderLiveClass = () => {
    if (!lesson || !lesson.live_id) return null;
    
    return (
      <div className="space-y-4">
        <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
          <h3 className="text-lg font-medium text-blue-800">Aula ao Vivo</h3>
          <p className="text-blue-600">
            Esta é uma aula ao vivo que ocorrerá em {lesson.lesson_date ? new Date(lesson.lesson_date).toLocaleString('pt-BR') : 'data a ser definida'}.
          </p>
          <Button className="mt-4">
            Entrar na Aula ao Vivo
          </Button>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="my-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!lesson) {
    return (
      <div className="text-center py-8">
        <h2 className="text-2xl font-bold">Aula não encontrada</h2>
        <p className="text-gray-500 mt-2">A aula que você está procurando não existe ou foi removida.</p>
        <Link to="/lessons">
          <Button className="mt-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para Lista de Aulas
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Link to="/lessons">
          <Button variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">{lesson.title}</h1>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {lesson.lesson_type === 'Video' ? renderVideoPlayer() : renderLiveClass()}
          
          <Card>
            <CardHeader>
              <CardTitle>Descrição da Aula</CardTitle>
              <CardDescription>
                {lesson.lesson_date && (
                  <span>Data: {new Date(lesson.lesson_date).toLocaleDateString('pt-BR')}</span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">
                {lesson.description || 'Nenhuma descrição disponível para esta aula.'}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Fórum de Discussão</CardTitle>
              <CardDescription>Compartilhe suas dúvidas e comentários sobre a aula</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {comments.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">Nenhum comentário ainda. Seja o primeiro a comentar!</p>
                ) : (
                  <div className="space-y-4">
                    {comments.map(comment => (
                      <div key={comment.id} className="p-4 border rounded-md">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{comment.user_name}</h4>
                            <span className="text-xs text-gray-500">{comment.user_type}</span>
                          </div>
                          <span className="text-xs text-gray-500">
                            {new Date(comment.created_at).toLocaleString('pt-BR')}
                          </span>
                        </div>
                        <p className="mt-2 text-gray-700">{comment.content}</p>
                      </div>
                    ))}
                  </div>
                )}
                
                <form onSubmit={handleCommentSubmit} className="mt-6">
                  <div className="flex flex-col space-y-2">
                    <textarea
                      className="w-full p-2 border rounded-md"
                      rows="3"
                      placeholder="Escreva seu comentário..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      required
                    ></textarea>
                    <Button type="submit" className="self-end">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Comentar
                    </Button>
                  </div>
                </form>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Materiais da Aula</CardTitle>
              <CardDescription>Arquivos disponíveis para download</CardDescription>
            </CardHeader>
            <CardContent>
              {materials.length === 0 ? (
                <p className="text-gray-500 text-center py-4">Nenhum material disponível para esta aula.</p>
              ) : (
                <div className="space-y-2">
                  {materials.map(material => (
                    <div key={material.id} className="flex justify-between items-center p-2 border rounded-md">
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 mr-2 text-blue-500" />
                        <span>{material.name}</span>
                      </div>
                      <a href={material.file_url} target="_blank" rel="noopener noreferrer">
                        <Button variant="ghost" size="sm">
                          <Download className="h-4 w-4" />
                        </Button>
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Informações da Turma</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Turma:</span>
                  <span className="font-medium">{lesson.class_name || `Turma ${lesson.class_id}`}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Professor:</span>
                  <span className="font-medium">{lesson.professor_name || 'Não atribuído'}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default LessonView;

