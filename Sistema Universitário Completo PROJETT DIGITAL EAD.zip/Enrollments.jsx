import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Plus, Pencil, Trash2 } from 'lucide-react';

const Enrollments = () => {
  const { currentUser } = useAuth();
  const [enrollments, setEnrollments] = useState([]);
  const [classes, setClasses] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentEnrollment, setCurrentEnrollment] = useState(null);
  const [formData, setFormData] = useState({
    student_id: '',
    class_id: ''
  });

  useEffect(() => {
    fetchEnrollments();
    fetchClasses();
    fetchStudents();
  }, []);

  const fetchEnrollments = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/enrollments');
      setEnrollments(response.data);
    } catch (error) {
      console.error('Erro ao buscar matrículas:', error);
      setError('Não foi possível carregar as matrículas. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchClasses = async () => {
    try {
      const response = await axios.get('/api/classes');
      setClasses(response.data);
    } catch (error) {
      console.error('Erro ao buscar turmas:', error);
    }
  };

  const fetchStudents = async () => {
    try {
      const response = await axios.get('/api/users?user_type=Aluno');
      setStudents(response.data);
    } catch (error) {
      console.error('Erro ao buscar alunos:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentEnrollment) {
        await axios.put(`/api/enrollments/${currentEnrollment.id}`, formData);
      } else {
        await axios.post('/api/enrollments', formData);
      }
      
      fetchEnrollments();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar matrícula:', error);
      setError(error.response?.data?.message || 'Erro ao salvar matrícula. Tente novamente.');
    }
  };

  const handleEdit = (enrollment) => {
    setCurrentEnrollment(enrollment);
    setFormData({
      student_id: enrollment.student_id,
      class_id: enrollment.class_id
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir esta matrícula?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/enrollments/${id}`);
      fetchEnrollments();
    } catch (error) {
      console.error('Erro ao excluir matrícula:', error);
      setError(error.response?.data?.message || 'Erro ao excluir matrícula. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      student_id: '',
      class_id: ''
    });
    setCurrentEnrollment(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const canManageEnrollments = ['Admin', 'Coordenador'].includes(currentUser.user_type);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Matrículas</h1>
          <p className="text-gray-500">Gerencie as matrículas dos alunos</p>
        </div>
        
        {canManageEnrollments && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Matrícula
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Matrícula' : 'Nova Matrícula'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações da matrícula abaixo.' 
                    : 'Preencha as informações para criar uma nova matrícula.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="student_id">Aluno</Label>
                  <select
                    id="student_id"
                    name="student_id"
                    value={formData.student_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione um aluno</option>
                    {students.map(student => (
                      <option key={student.id} value={student.id}>
                        {student.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="class_id">Turma</Label>
                  <select
                    id="class_id"
                    name="class_id"
                    value={formData.class_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione uma turma</option>
                    {classes.map(classItem => (
                      <option key={classItem.id} value={classItem.id}>
                        {classItem.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Criar Matrícula'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardHeader>
          <CardTitle>Lista de Matrículas</CardTitle>
          <CardDescription>Todas as matrículas realizadas</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : enrollments.length === 0 ? (
            <p className="text-center text-gray-500 py-4">Nenhuma matrícula encontrada.</p>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Aluno</TableHead>
                    <TableHead>Turma</TableHead>
                    <TableHead>Data de Matrícula</TableHead>
                    {canManageEnrollments && <TableHead className="w-24">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {enrollments.map(enrollment => (
                    <TableRow key={enrollment.id}>
                      <TableCell>
                        {students.find(s => s.id === enrollment.student_id)?.name || `Aluno ${enrollment.student_id}`}
                      </TableCell>
                      <TableCell>
                        {classes.find(c => c.id === enrollment.class_id)?.name || `Turma ${enrollment.class_id}`}
                      </TableCell>
                      <TableCell>
                        {enrollment.enrollment_date 
                          ? new Date(enrollment.enrollment_date).toLocaleDateString('pt-BR') 
                          : 'Não registrada'}
                      </TableCell>
                      {canManageEnrollments && (
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(enrollment)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(enrollment.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Enrollments;

