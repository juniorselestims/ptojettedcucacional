import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Plus, Pencil, Trash2 } from 'lucide-react';

const Courses = () => {
  const { currentUser } = useAuth();
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentCourse, setCurrentCourse] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    coordinator_id: ''
  });
  const [coordinators, setCoordinators] = useState([]);

  useEffect(() => {
    fetchCourses();
    fetchCoordinators();
  }, []);

  const fetchCourses = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/courses');
      setCourses(response.data);
    } catch (error) {
      console.error('Erro ao buscar cursos:', error);
      setError('Não foi possível carregar os cursos. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchCoordinators = async () => {
    try {
      const response = await axios.get('/api/users?user_type=Coordenador');
      setCoordinators(response.data);
    } catch (error) {
      console.error('Erro ao buscar coordenadores:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentCourse) {
        await axios.put(`/api/courses/${currentCourse.id}`, formData);
      } else {
        await axios.post('/api/courses', formData);
      }
      
      fetchCourses();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar curso:', error);
      setError(error.response?.data?.message || 'Erro ao salvar curso. Tente novamente.');
    }
  };

  const handleEdit = (course) => {
    setCurrentCourse(course);
    setFormData({
      name: course.name,
      description: course.description,
      coordinator_id: course.coordinator_id
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir este curso?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/courses/${id}`);
      fetchCourses();
    } catch (error) {
      console.error('Erro ao excluir curso:', error);
      setError(error.response?.data?.message || 'Erro ao excluir curso. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      coordinator_id: ''
    });
    setCurrentCourse(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const canManageCourses = ['Admin', 'Coordenador'].includes(currentUser.user_type);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Cursos</h1>
          <p className="text-gray-500">Gerencie os cursos da instituição</p>
        </div>
        
        {canManageCourses && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Curso
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Curso' : 'Novo Curso'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações do curso abaixo.' 
                    : 'Preencha as informações para criar um novo curso.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome do Curso</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows={3}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="coordinator_id">Coordenador</Label>
                  <select
                    id="coordinator_id"
                    name="coordinator_id"
                    value={formData.coordinator_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                  >
                    <option value="">Selecione um coordenador</option>
                    {coordinators.map(coordinator => (
                      <option key={coordinator.id} value={coordinator.id}>
                        {coordinator.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Criar Curso'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardHeader>
          <CardTitle>Lista de Cursos</CardTitle>
          <CardDescription>Todos os cursos disponíveis na instituição</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : courses.length === 0 ? (
            <p className="text-center text-gray-500 py-4">Nenhum curso encontrado.</p>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Coordenador</TableHead>
                    {canManageCourses && <TableHead className="w-24">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {courses.map(course => (
                    <TableRow key={course.id}>
                      <TableCell className="font-medium">{course.name}</TableCell>
                      <TableCell>{course.description}</TableCell>
                      <TableCell>{course.coordinator_name || 'Não atribuído'}</TableCell>
                      {canManageCourses && (
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(course)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(course.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Courses;

