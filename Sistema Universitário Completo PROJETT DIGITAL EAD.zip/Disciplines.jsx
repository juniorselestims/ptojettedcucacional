import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Plus, Pencil, Trash2 } from 'lucide-react';

const Disciplines = () => {
  const { currentUser } = useAuth();
  const [disciplines, setDisciplines] = useState([]);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentDiscipline, setCurrentDiscipline] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    course_id: ''
  });

  useEffect(() => {
    fetchDisciplines();
    fetchCourses();
  }, []);

  const fetchDisciplines = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/disciplines');
      setDisciplines(response.data);
    } catch (error) {
      console.error('Erro ao buscar disciplinas:', error);
      setError('Não foi possível carregar as disciplinas. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchCourses = async () => {
    try {
      const response = await axios.get('/api/courses');
      setCourses(response.data);
    } catch (error) {
      console.error('Erro ao buscar cursos:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentDiscipline) {
        await axios.put(`/api/disciplines/${currentDiscipline.id}`, formData);
      } else {
        await axios.post('/api/disciplines', formData);
      }
      
      fetchDisciplines();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar disciplina:', error);
      setError(error.response?.data?.message || 'Erro ao salvar disciplina. Tente novamente.');
    }
  };

  const handleEdit = (discipline) => {
    setCurrentDiscipline(discipline);
    setFormData({
      name: discipline.name,
      course_id: discipline.course_id
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir esta disciplina?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/disciplines/${id}`);
      fetchDisciplines();
    } catch (error) {
      console.error('Erro ao excluir disciplina:', error);
      setError(error.response?.data?.message || 'Erro ao excluir disciplina. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      course_id: ''
    });
    setCurrentDiscipline(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const canManageDisciplines = ['Admin', 'Coordenador'].includes(currentUser.user_type);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Disciplinas</h1>
          <p className="text-gray-500">Gerencie as disciplinas dos cursos</p>
        </div>
        
        {canManageDisciplines && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Disciplina
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Disciplina' : 'Nova Disciplina'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações da disciplina abaixo.' 
                    : 'Preencha as informações para criar uma nova disciplina.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome da Disciplina</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="course_id">Curso</Label>
                  <select
                    id="course_id"
                    name="course_id"
                    value={formData.course_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione um curso</option>
                    {courses.map(course => (
                      <option key={course.id} value={course.id}>
                        {course.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Criar Disciplina'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardHeader>
          <CardTitle>Lista de Disciplinas</CardTitle>
          <CardDescription>Todas as disciplinas disponíveis</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : disciplines.length === 0 ? (
            <p className="text-center text-gray-500 py-4">Nenhuma disciplina encontrada.</p>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Curso</TableHead>
                    {canManageDisciplines && <TableHead className="w-24">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {disciplines.map(discipline => (
                    <TableRow key={discipline.id}>
                      <TableCell className="font-medium">{discipline.name}</TableCell>
                      <TableCell>
                        {courses.find(c => c.id === discipline.course_id)?.name || 'Curso não encontrado'}
                      </TableCell>
                      {canManageDisciplines && (
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(discipline)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(discipline.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Disciplines;

