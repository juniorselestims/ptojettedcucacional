import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Plus, Pencil, Trash2 } from 'lucide-react';

const Classes = () => {
  const { currentUser } = useAuth();
  const [classes, setClasses] = useState([]);
  const [disciplines, setDisciplines] = useState([]);
  const [professors, setProfessors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentClass, setCurrentClass] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    discipline_id: '',
    professor_id: '',
    academic_year: new Date().getFullYear().toString()
  });

  useEffect(() => {
    fetchClasses();
    fetchDisciplines();
    fetchProfessors();
  }, []);

  const fetchClasses = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/classes');
      setClasses(response.data);
    } catch (error) {
      console.error('Erro ao buscar turmas:', error);
      setError('Não foi possível carregar as turmas. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchDisciplines = async () => {
    try {
      const response = await axios.get('/api/disciplines');
      setDisciplines(response.data);
    } catch (error) {
      console.error('Erro ao buscar disciplinas:', error);
    }
  };

  const fetchProfessors = async () => {
    try {
      const response = await axios.get('/api/users?user_type=Professor');
      setProfessors(response.data);
    } catch (error) {
      console.error('Erro ao buscar professores:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentClass) {
        await axios.put(`/api/classes/${currentClass.id}`, formData);
      } else {
        await axios.post('/api/classes', formData);
      }
      
      fetchClasses();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar turma:', error);
      setError(error.response?.data?.message || 'Erro ao salvar turma. Tente novamente.');
    }
  };

  const handleEdit = (classItem) => {
    setCurrentClass(classItem);
    setFormData({
      name: classItem.name,
      discipline_id: classItem.discipline_id,
      professor_id: classItem.professor_id || '',
      academic_year: classItem.academic_year || new Date().getFullYear().toString()
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir esta turma?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/classes/${id}`);
      fetchClasses();
    } catch (error) {
      console.error('Erro ao excluir turma:', error);
      setError(error.response?.data?.message || 'Erro ao excluir turma. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      discipline_id: '',
      professor_id: '',
      academic_year: new Date().getFullYear().toString()
    });
    setCurrentClass(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const canManageClasses = ['Admin', 'Coordenador'].includes(currentUser.user_type);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Turmas</h1>
          <p className="text-gray-500">Gerencie as turmas das disciplinas</p>
        </div>
        
        {canManageClasses && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Turma
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Turma' : 'Nova Turma'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações da turma abaixo.' 
                    : 'Preencha as informações para criar uma nova turma.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome da Turma</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="discipline_id">Disciplina</Label>
                  <select
                    id="discipline_id"
                    name="discipline_id"
                    value={formData.discipline_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione uma disciplina</option>
                    {disciplines.map(discipline => (
                      <option key={discipline.id} value={discipline.id}>
                        {discipline.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="professor_id">Professor</Label>
                  <select
                    id="professor_id"
                    name="professor_id"
                    value={formData.professor_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                  >
                    <option value="">Selecione um professor</option>
                    {professors.map(professor => (
                      <option key={professor.id} value={professor.id}>
                        {professor.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="academic_year">Ano Letivo</Label>
                  <Input
                    id="academic_year"
                    name="academic_year"
                    value={formData.academic_year}
                    onChange={handleChange}
                    placeholder="2025"
                  />
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Criar Turma'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardHeader>
          <CardTitle>Lista de Turmas</CardTitle>
          <CardDescription>Todas as turmas disponíveis</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : classes.length === 0 ? (
            <p className="text-center text-gray-500 py-4">Nenhuma turma encontrada.</p>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Disciplina</TableHead>
                    <TableHead>Professor</TableHead>
                    <TableHead>Ano Letivo</TableHead>
                    {canManageClasses && <TableHead className="w-24">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {classes.map(classItem => (
                    <TableRow key={classItem.id}>
                      <TableCell className="font-medium">{classItem.name}</TableCell>
                      <TableCell>
                        {disciplines.find(d => d.id === classItem.discipline_id)?.name || 'Disciplina não encontrada'}
                      </TableCell>
                      <TableCell>
                        {professors.find(p => p.id === classItem.professor_id)?.name || 'Não atribuído'}
                      </TableCell>
                      <TableCell>{classItem.academic_year || 'Não definido'}</TableCell>
                      {canManageClasses && (
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(classItem)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(classItem.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Classes;

