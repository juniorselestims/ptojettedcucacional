from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.discipline import Discipline, db
from src.models.user import User

discipline_bp = Blueprint('discipline', __name__)

@discipline_bp.route('/disciplines', methods=['GET'])
@jwt_required()
def get_disciplines():
    disciplines = Discipline.query.all()
    return jsonify([{
        'id': discipline.id,
        'name': discipline.name,
        'course_id': discipline.course_id
    } for discipline in disciplines]), 200

@discipline_bp.route('/disciplines/<int:discipline_id>', methods=['GET'])
@jwt_required()
def get_discipline(discipline_id):
    discipline = Discipline.query.get(discipline_id)
    if not discipline:
        return jsonify({'message': 'Disciplina não encontrada'}), 404
    
    return jsonify({
        'id': discipline.id,
        'name': discipline.name,
        'course_id': discipline.course_id
    }), 200

@discipline_bp.route('/disciplines', methods=['POST'])
@jwt_required()
def create_discipline():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    name = data.get('name')
    course_id = data.get('course_id')
    
    if not name or not course_id:
        return jsonify({'message': 'Nome da disciplina e ID do curso são obrigatórios'}), 400
    
    new_discipline = Discipline(
        name=name,
        course_id=course_id
    )
    
    db.session.add(new_discipline)
    db.session.commit()
    
    return jsonify({'message': 'Disciplina criada com sucesso', 'id': new_discipline.id}), 201

@discipline_bp.route('/disciplines/<int:discipline_id>', methods=['PUT'])
@jwt_required()
def update_discipline(discipline_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    discipline = Discipline.query.get(discipline_id)
    if not discipline:
        return jsonify({'message': 'Disciplina não encontrada'}), 404
    
    data = request.get_json()
    discipline.name = data.get('name', discipline.name)
    discipline.course_id = data.get('course_id', discipline.course_id)
    
    db.session.commit()
    
    return jsonify({'message': 'Disciplina atualizada com sucesso'}), 200

@discipline_bp.route('/disciplines/<int:discipline_id>', methods=['DELETE'])
@jwt_required()
def delete_discipline(discipline_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type != 'Admin':
        return jsonify({'message': 'Acesso negado'}), 403
    
    discipline = Discipline.query.get(discipline_id)
    if not discipline:
        return jsonify({'message': 'Disciplina não encontrada'}), 404
    
    db.session.delete(discipline)
    db.session.commit()
    
    return jsonify({'message': 'Disciplina excluída com sucesso'}), 200

