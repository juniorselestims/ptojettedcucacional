# Guia de Instalação - PROJETT DIGITAL EAD

Este guia fornece instruções detalhadas para instalar e configurar o sistema PROJETT DIGITAL EAD em ambientes de desenvolvimento e produção.

## Sumário

1. [Requisitos do Sistema](#requisitos-do-sistema)
2. [Instalação em Ambiente de Desenvolvimento](#instalação-em-ambiente-de-desenvolvimento)
3. [Configuração do Banco de Dados](#configuração-do-banco-de-dados)
4. [Configuração das Integrações](#configuração-das-integrações)
5. [Instalação em Ambiente de Produção](#instalação-em-ambiente-de-produção)
6. [Solução de Problemas Comuns](#solução-de-problemas-comuns)

## Requisitos do Sistema

### Hardware Recomendado

- **Desenvolvimento**:
  - Processador: 2+ núcleos
  - Memória RAM: 4GB+
  - Armazenamento: 10GB+ de espaço livre

- **Produção**:
  - Processador: 4+ núcleos
  - Memória RAM: 8GB+
  - Armazenamento: 50GB+ de espaço livre (dependendo do volume esperado de arquivos)

### Software Necessário

- **Sistema Operacional**: Linux (recomendado), macOS ou Windows
- **Python**: Versão 3.8 ou superior
- **Node.js**: Versão 14 ou superior
- **PostgreSQL**: Versão 12 ou superior (para produção)
- **Git**: Para controle de versão

## Instalação em Ambiente de Desenvolvimento

### 1. Preparação do Ambiente

Primeiro, instale as ferramentas necessárias:

#### Ubuntu/Debian:

```bash
# Atualizar repositórios
sudo apt update

# Instalar Python, pip e venv
sudo apt install python3 python3-pip python3-venv

# Instalar Node.js e npm
curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt install nodejs

# Instalar PostgreSQL (opcional para desenvolvimento)
sudo apt install postgresql postgresql-contrib

# Instalar Git
sudo apt install git
```

#### macOS (usando Homebrew):

```bash
# Instalar Homebrew (se ainda não estiver instalado)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Python
brew install python

# Instalar Node.js
brew install node

# Instalar PostgreSQL (opcional para desenvolvimento)
brew install postgresql

# Instalar Git
brew install git
```

#### Windows:

- Baixe e instale Python: https://www.python.org/downloads/
- Baixe e instale Node.js: https://nodejs.org/
- Baixe e instale Git: https://git-scm.com/download/win
- Baixe e instale PostgreSQL (opcional): https://www.postgresql.org/download/windows/

### 2. Clonar o Repositório

```bash
# Clonar o repositório
git clone https://github.com/projett-digital/ead-system.git
cd ead-system
```

### 3. Configurar o Backend

```bash
# Navegar para a pasta do backend
cd backend

# Criar ambiente virtual Python
python3 -m venv venv

# Ativar o ambiente virtual
source venv/bin/activate  # No Windows: venv\Scripts\activate

# Instalar dependências
pip install -r requirements.txt

# Criar arquivo de variáveis de ambiente
cp .env.example .env

# Editar o arquivo .env com suas configurações
# Exemplo:
# FLASK_APP=src/main.py
# FLASK_ENV=development
# DATABASE_URL=sqlite:///src/database/app.db
# JWT_SECRET_KEY=seu_segredo_jwt
# ZOOM_API_KEY=sua_chave_zoom
# ZOOM_API_SECRET=seu_segredo_zoom
# MERCADO_PAGO_API_KEY=sua_chave_mercado_pago
# EMAIL_SENDER=seu_email@exemplo.com
# EMAIL_PASSWORD=sua_senha_email
# SMTP_SERVER=smtp.gmail.com
# SMTP_PORT=587
# WHATSAPP_API_KEY=sua_chave_whatsapp
# WHATSAPP_API_URL=https://api.whatsapp.com/v1/messages

# Inicializar o banco de dados SQLite (para desenvolvimento)
flask db init
flask db migrate -m "Initial migration"
flask db upgrade
```

### 4. Configurar o Frontend

```bash
# Navegar para a pasta do frontend
cd ../frontend

# Instalar dependências
npm install

# Criar arquivo de variáveis de ambiente
cp .env.example .env

# Editar o arquivo .env com suas configurações
# Exemplo:
# VITE_API_URL=http://localhost:5000/api
```

### 5. Executar o Sistema em Desenvolvimento

#### Terminal 1 (Backend):

```bash
# Na pasta backend, com o ambiente virtual ativado
python src/main.py
# O servidor backend estará disponível em http://localhost:5000
```

#### Terminal 2 (Frontend):

```bash
# Na pasta frontend
npm run dev
# O servidor frontend estará disponível em http://localhost:5173
```

## Configuração do Banco de Dados

### SQLite (Desenvolvimento)

O SQLite é configurado automaticamente para desenvolvimento. O arquivo do banco de dados será criado em `backend/src/database/app.db`.

### PostgreSQL (Produção)

Para configurar o PostgreSQL:

1. Crie um banco de dados e um usuário:

```bash
# Acessar o PostgreSQL
sudo -u postgres psql

# Criar usuário
CREATE USER projett_user WITH PASSWORD 'sua_senha_segura';

# Criar banco de dados
CREATE DATABASE projett_ead;

# Conceder privilégios
GRANT ALL PRIVILEGES ON DATABASE projett_ead TO projett_user;

# Sair do PostgreSQL
\q
```

2. Atualize o arquivo `.env` do backend:

```
DATABASE_URL=postgresql://projett_user:sua_senha_segura@localhost/projett_ead
```

3. Execute as migrações:

```bash
# Na pasta backend, com o ambiente virtual ativado
flask db upgrade
```

## Configuração das Integrações

### Zoom (Aulas ao Vivo)

1. Crie uma conta de desenvolvedor no Zoom: https://marketplace.zoom.us/
2. Crie um aplicativo JWT
3. Obtenha a API Key e API Secret
4. Atualize o arquivo `.env` do backend:

```
ZOOM_API_KEY=sua_chave_zoom
ZOOM_API_SECRET=seu_segredo_zoom
```

### Mercado Pago (Pagamentos)

1. Crie uma conta no Mercado Pago: https://www.mercadopago.com.br/
2. Acesse o painel de desenvolvedores
3. Crie uma aplicação e obtenha a chave de acesso
4. Atualize o arquivo `.env` do backend:

```
MERCADO_PAGO_API_KEY=sua_chave_mercado_pago
```

### E-mail (Notificações)

Configure as credenciais de e-mail para envio de notificações:

```
EMAIL_SENDER=seu_email@exemplo.com
EMAIL_PASSWORD=sua_senha_email
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
```

Para Gmail, você precisará criar uma senha de aplicativo: https://myaccount.google.com/apppasswords

### WhatsApp (Notificações)

Para integração com WhatsApp, você precisará de uma conta na API oficial do WhatsApp Business ou em provedores como Twilio:

```
WHATSAPP_API_KEY=sua_chave_whatsapp
WHATSAPP_API_URL=https://api.whatsapp.com/v1/messages
```

## Instalação em Ambiente de Produção

### 1. Preparação do Servidor

Recomendamos usar um servidor Linux (Ubuntu Server 20.04 LTS ou superior).

```bash
# Atualizar o sistema
sudo apt update
sudo apt upgrade -y

# Instalar dependências
sudo apt install python3 python3-pip python3-venv nodejs npm postgresql nginx certbot python3-certbot-nginx git
```

### 2. Configurar o PostgreSQL

```bash
# Criar usuário e banco de dados (como feito anteriormente)
sudo -u postgres psql
CREATE USER projett_user WITH PASSWORD 'sua_senha_segura';
CREATE DATABASE projett_ead;
GRANT ALL PRIVILEGES ON DATABASE projett_ead TO projett_user;
\q
```

### 3. Clonar e Configurar o Repositório

```bash
# Clonar o repositório em /var/www
sudo mkdir -p /var/www
sudo chown $USER:$USER /var/www
cd /var/www
git clone https://github.com/projett-digital/ead-system.git
cd ead-system

# Configurar o backend
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn  # Servidor WSGI para produção

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com as configurações de produção

# Executar migrações
flask db upgrade

# Configurar o frontend
cd ../frontend
npm install
npm run build  # Criar build de produção
```

### 4. Configurar o Gunicorn (Servidor WSGI)

Crie um arquivo de serviço systemd para o backend:

```bash
sudo nano /etc/systemd/system/projett-backend.service
```

Adicione o seguinte conteúdo:

```ini
[Unit]
Description=Projett Digital EAD Backend
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/ead-system/backend
Environment="PATH=/var/www/ead-system/backend/venv/bin"
EnvironmentFile=/var/www/ead-system/backend/.env
ExecStart=/var/www/ead-system/backend/venv/bin/gunicorn --workers 4 --bind 0.0.0.0:5000 --access-logfile /var/log/projett-ead/backend-access.log --error-logfile /var/log/projett-ead/backend-error.log src.main:app

[Install]
WantedBy=multi-user.target
```

Crie o diretório de logs:

```bash
sudo mkdir -p /var/log/projett-ead
sudo chown www-data:www-data /var/log/projett-ead
```

Inicie o serviço:

```bash
sudo systemctl enable projett-backend
sudo systemctl start projett-backend
```

### 5. Configurar o Nginx

Crie um arquivo de configuração para o Nginx:

```bash
sudo nano /etc/nginx/sites-available/projett-ead
```

Adicione o seguinte conteúdo:

```nginx
server {
    listen 80;
    server_name seu-dominio.com www.seu-dominio.com;

    # Redirecionar para HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name seu-dominio.com www.seu-dominio.com;

    # Certificados SSL (serão configurados pelo Certbot)
    # ssl_certificate /etc/letsencrypt/live/seu-dominio.com/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/seu-dominio.com/privkey.pem;

    # Frontend
    location / {
        root /var/www/ead-system/frontend/dist;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Logs
    access_log /var/log/nginx/projett-ead-access.log;
    error_log /var/log/nginx/projett-ead-error.log;
}
```

Ative a configuração:

```bash
sudo ln -s /etc/nginx/sites-available/projett-ead /etc/nginx/sites-enabled/
sudo nginx -t  # Testar a configuração
sudo systemctl restart nginx
```

### 6. Configurar SSL com Certbot

```bash
sudo certbot --nginx -d seu-dominio.com -d www.seu-dominio.com
```

Siga as instruções do Certbot para configurar o SSL.

### 7. Configurar Backup Automático

Crie um script de backup:

```bash
sudo nano /usr/local/bin/backup-projett-ead.sh
```

Adicione o seguinte conteúdo:

```bash
#!/bin/bash
BACKUP_DIR="/var/backups/projett-ead"
DATE=$(date +%Y%m%d_%H%M%S)
FILENAME="projett_ead_backup_$DATE.sql"

# Criar diretório de backup se não existir
mkdir -p $BACKUP_DIR

# Backup do banco de dados
pg_dump -U projett_user projett_ead > $BACKUP_DIR/$FILENAME

# Compactar o backup
gzip $BACKUP_DIR/$FILENAME

# Remover backups com mais de 30 dias
find $BACKUP_DIR -name "projett_ead_backup_*.sql.gz" -mtime +30 -delete
```

Torne o script executável:

```bash
sudo chmod +x /usr/local/bin/backup-projett-ead.sh
```

Configure um cron job para executar o backup diariamente:

```bash
sudo crontab -e
```

Adicione a linha:

```
0 2 * * * /usr/local/bin/backup-projett-ead.sh
```

Isso executará o backup todos os dias às 2h da manhã.

## Solução de Problemas Comuns

### Problemas de Conexão com o Banco de Dados

**Sintoma**: Erro ao conectar ao banco de dados.

**Solução**:
1. Verifique se o PostgreSQL está em execução:
   ```bash
   sudo systemctl status postgresql
   ```
2. Verifique as credenciais no arquivo `.env`
3. Teste a conexão manualmente:
   ```bash
   psql -U projett_user -h localhost projett_ead
   ```

### Problemas com o Backend

**Sintoma**: O servidor backend não inicia ou retorna erros.

**Solução**:
1. Verifique os logs:
   ```bash
   sudo journalctl -u projett-backend
   cat /var/log/projett-ead/backend-error.log
   ```
2. Verifique se todas as dependências estão instaladas:
   ```bash
   source venv/bin/activate
   pip install -r requirements.txt
   ```
3. Verifique as permissões dos arquivos:
   ```bash
   sudo chown -R www-data:www-data /var/www/ead-system
   ```

### Problemas com o Frontend

**Sintoma**: O frontend não carrega ou não consegue se comunicar com o backend.

**Solução**:
1. Verifique se o build foi gerado corretamente:
   ```bash
   ls -la /var/www/ead-system/frontend/dist
   ```
2. Verifique a configuração do Nginx:
   ```bash
   sudo nginx -t
   ```
3. Verifique os logs do Nginx:
   ```bash
   cat /var/log/nginx/projett-ead-error.log
   ```
4. Verifique se a URL da API está configurada corretamente no frontend.

### Problemas com SSL

**Sintoma**: Certificado SSL inválido ou expirado.

**Solução**:
1. Renovar o certificado:
   ```bash
   sudo certbot renew
   ```
2. Verificar a configuração do SSL:
   ```bash
   sudo nginx -t
   ```
3. Reiniciar o Nginx:
   ```bash
   sudo systemctl restart nginx
   ```

### Problemas de Permissão

**Sintoma**: Erros de permissão ao acessar arquivos ou diretórios.

**Solução**:
1. Verificar e corrigir as permissões:
   ```bash
   sudo chown -R www-data:www-data /var/www/ead-system
   sudo chmod -R 755 /var/www/ead-system
   sudo chmod -R 700 /var/www/ead-system/backend/venv
   ```

## Suporte Adicional

Para suporte técnico adicional, entre em contato:

- E-mail: suporte@projettdigital.com.br
- Telefone: (XX) XXXX-XXXX
- Horário de atendimento: Segunda a Sexta, das 8h às 18h

