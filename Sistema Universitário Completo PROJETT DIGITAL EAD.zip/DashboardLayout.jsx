import { useState } from 'react';
import { Outlet, Navigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  Home, 
  BookOpen, 
  Video, 
  FileText, 
  DollarSign, 
  Library, 
  LifeBuoy, 
  Users, 
  User, 
  Menu, 
  X, 
  LogOut 
} from 'lucide-react';

const DashboardLayout = () => {
  const { currentUser, loading, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  const navigation = [
    { name: 'Dashboard', href: '/', icon: Home },
    { name: 'Cursos', href: '/courses', icon: BookOpen, roles: ['Admin', 'Coordenador', 'Professor'] },
    { name: 'Disciplinas', href: '/disciplines', icon: BookOpen, roles: ['Admin', 'Coordenador', 'Professor'] },
    { name: 'Turmas', href: '/classes', icon: Users, roles: ['Admin', 'Coordenador', 'Professor'] },
    { name: 'Matrículas', href: '/enrollments', icon: FileText, roles: ['Admin', 'Coordenador'] },
    { name: 'Aulas', href: '/lessons', icon: Video },
    { name: 'Avaliações', href: '/assessments', icon: FileText },
    { name: 'Notas', href: '/grades', icon: FileText },
    { name: 'Financeiro', href: '/invoices', icon: DollarSign, roles: ['Admin', 'Financeiro', 'Aluno'] },
    { name: 'Planos', href: '/tuition-plans', icon: DollarSign, roles: ['Admin', 'Financeiro'] },
    { name: 'Biblioteca', href: '/books', icon: Library },
    { name: 'Suporte', href: '/tickets', icon: LifeBuoy },
    { name: 'Usuários', href: '/users', icon: Users, roles: ['Admin'] },
  ];

  const filteredNavigation = navigation.filter(item => {
    if (!item.roles) return true;
    return item.roles.includes(currentUser.user_type);
  });

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Mobile sidebar */}
      <div className={`fixed inset-0 z-40 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setSidebarOpen(false)}></div>
        <div className="fixed inset-y-0 left-0 flex flex-col w-64 bg-white border-r border-gray-200">
          <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
            <span className="text-xl font-semibold">PROJETT DIGITAL</span>
            <button onClick={() => setSidebarOpen(false)} className="text-gray-500 hover:text-gray-700">
              <X size={24} />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto">
            <nav className="px-2 py-4 space-y-1">
              {filteredNavigation.map((item) => {
                const isActive = location.pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                      isActive
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <item.icon className={`mr-3 h-5 w-5 ${isActive ? 'text-blue-500' : 'text-gray-500'}`} />
                    {item.name}
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      </div>

      {/* Static sidebar for desktop */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col">
        <div className="flex flex-col flex-1 min-h-0 bg-white border-r border-gray-200">
          <div className="flex items-center h-16 px-4 border-b border-gray-200">
            <span className="text-xl font-semibold">PROJETT DIGITAL</span>
          </div>
          <div className="flex-1 overflow-y-auto">
            <nav className="px-2 py-4 space-y-1">
              {filteredNavigation.map((item) => {
                const isActive = location.pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                      isActive
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <item.icon className={`mr-3 h-5 w-5 ${isActive ? 'text-blue-500' : 'text-gray-500'}`} />
                    {item.name}
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        <div className="sticky top-0 z-10 flex items-center justify-between h-16 px-4 bg-white border-b border-gray-200 sm:px-6 lg:px-8">
          <button
            type="button"
            className="lg:hidden -ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900"
            onClick={() => setSidebarOpen(true)}
          >
            <span className="sr-only">Abrir menu lateral</span>
            <Menu className="h-6 w-6" />
          </button>
          <div className="flex items-center">
            <Link to="/profile" className="flex items-center text-sm font-medium text-gray-700 hover:text-gray-900">
              <User className="mr-2 h-5 w-5 text-gray-500" />
              {currentUser.name}
            </Link>
            <button
              onClick={logout}
              className="ml-4 flex items-center text-sm font-medium text-gray-700 hover:text-gray-900"
            >
              <LogOut className="mr-2 h-5 w-5 text-gray-500" />
              Sair
            </button>
          </div>
        </div>

        <main className="py-6 px-4 sm:px-6 lg:px-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;

