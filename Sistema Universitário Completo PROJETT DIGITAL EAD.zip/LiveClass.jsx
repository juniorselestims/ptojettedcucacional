import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { AlertCircle, ArrowLeft, Send, Users, UserCheck } from 'lucide-react';

const LiveClass = () => {
  const { id } = useParams();
  const { currentUser } = useAuth();
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [chatMessages, setChatMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [attendees, setAttendees] = useState([]);
  const [isPresent, setIsPresent] = useState(false);

  useEffect(() => {
    fetchLesson();
    fetchAttendees();
    
    // Simular mensagens de chat
    const simulatedMessages = [
      {
        id: 1,
        user_name: 'João Silva',
        user_type: 'Aluno',
        content: 'Olá, professor! Estou com uma dúvida sobre o slide 15.',
        timestamp: new Date(Date.now() - 15 * 60000).toISOString()
      },
      {
        id: 2,
        user_name: 'Maria Oliveira',
        user_type: 'Professor',
        content: 'Claro, João! Qual é a sua dúvida específica?',
        timestamp: new Date(Date.now() - 14 * 60000).toISOString()
      },
      {
        id: 3,
        user_name: 'João Silva',
        user_type: 'Aluno',
        content: 'Não entendi bem como funciona o processo descrito no diagrama.',
        timestamp: new Date(Date.now() - 13 * 60000).toISOString()
      },
      {
        id: 4,
        user_name: 'Maria Oliveira',
        user_type: 'Professor',
        content: 'Vou explicar novamente. O diagrama mostra o fluxo de dados entre os componentes do sistema...',
        timestamp: new Date(Date.now() - 12 * 60000).toISOString()
      }
    ];
    
    setChatMessages(simulatedMessages);
    
    // Marcar presença automaticamente
    markAttendance();
  }, [id]);

  const fetchLesson = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`/api/lessons/${id}`);
      setLesson(response.data);
    } catch (error) {
      console.error('Erro ao buscar aula:', error);
      setError('Não foi possível carregar a aula. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchAttendees = async () => {
    try {
      // Simulando busca de participantes
      const simulatedAttendees = [
        { id: 1, name: 'João Silva', user_type: 'Aluno' },
        { id: 2, name: 'Maria Oliveira', user_type: 'Professor' },
        { id: 3, name: 'Pedro Santos', user_type: 'Aluno' },
        { id: 4, name: 'Ana Souza', user_type: 'Aluno' },
        { id: 5, name: 'Carlos Ferreira', user_type: 'Aluno' }
      ];
      
      setAttendees(simulatedAttendees);
    } catch (error) {
      console.error('Erro ao buscar participantes:', error);
    }
  };

  const markAttendance = async () => {
    try {
      // Simulando marcação de presença
      console.log(`Marcando presença para o usuário ${currentUser.id} na aula ${id}`);
      setIsPresent(true);
    } catch (error) {
      console.error('Erro ao marcar presença:', error);
    }
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;
    
    // Simulando envio de mensagem
    const message = {
      id: chatMessages.length + 1,
      user_name: currentUser.name,
      user_type: currentUser.user_type,
      content: newMessage,
      timestamp: new Date().toISOString()
    };
    
    setChatMessages([...chatMessages, message]);
    setNewMessage('');
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="my-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!lesson) {
    return (
      <div className="text-center py-8">
        <h2 className="text-2xl font-bold">Aula não encontrada</h2>
        <p className="text-gray-500 mt-2">A aula que você está procurando não existe ou foi removida.</p>
        <Link to="/lessons">
          <Button className="mt-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para Lista de Aulas
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Link to={`/lessons/${id}`}>
          <Button variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para Detalhes da Aula
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">{lesson.title} - Aula ao Vivo</h1>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
            <div className="text-center text-white">
              <h3 className="text-xl font-bold mb-2">Transmissão ao Vivo</h3>
              <p className="mb-4">A transmissão será iniciada em breve.</p>
              <Button>Entrar na Sala de Videoconferência</Button>
            </div>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Chat ao Vivo</CardTitle>
              <CardDescription>Interaja com o professor e outros alunos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 overflow-y-auto border rounded-md p-4 mb-4">
                {chatMessages.map(message => (
                  <div key={message.id} className={`mb-4 ${message.user_name === currentUser.name ? 'text-right' : ''}`}>
                    <div className={`inline-block max-w-3/4 p-3 rounded-lg ${
                      message.user_name === currentUser.name 
                        ? 'bg-blue-100 text-blue-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      <div className="flex items-center mb-1">
                        <span className="font-medium">{message.user_name}</span>
                        <span className="text-xs ml-2 text-gray-500">{message.user_type}</span>
                      </div>
                      <p>{message.content}</p>
                      <span className="text-xs text-gray-500">
                        {new Date(message.timestamp).toLocaleTimeString('pt-BR')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              
              <form onSubmit={handleSendMessage} className="flex space-x-2">
                <Input
                  placeholder="Digite sua mensagem..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit">
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Participantes ({attendees.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {attendees.map(attendee => (
                  <div key={attendee.id} className="flex justify-between items-center p-2 border-b">
                    <div>
                      <span className="font-medium">{attendee.name}</span>
                      <span className="text-xs text-gray-500 ml-2">{attendee.user_type}</span>
                    </div>
                    {attendee.name === currentUser.name && (
                      <span className="text-green-500 flex items-center text-xs">
                        <UserCheck className="h-3 w-3 mr-1" />
                        Presente
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Informações da Aula</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Turma:</span>
                  <span className="font-medium">{lesson.class_name || `Turma ${lesson.class_id}`}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Professor:</span>
                  <span className="font-medium">{lesson.professor_name || 'Não atribuído'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Data:</span>
                  <span className="font-medium">
                    {lesson.lesson_date 
                      ? new Date(lesson.lesson_date).toLocaleDateString('pt-BR') 
                      : 'Não definida'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Horário:</span>
                  <span className="font-medium">
                    {lesson.lesson_date 
                      ? new Date(lesson.lesson_date).toLocaleTimeString('pt-BR') 
                      : 'Não definido'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Status:</span>
                  <span className="font-medium text-green-500">Ao Vivo</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Sua Presença</CardTitle>
            </CardHeader>
            <CardContent>
              {isPresent ? (
                <div className="bg-green-50 p-4 rounded-md border border-green-200 text-center">
                  <UserCheck className="h-8 w-8 mx-auto text-green-500 mb-2" />
                  <p className="text-green-700 font-medium">Presença Registrada</p>
                  <p className="text-green-600 text-sm mt-1">Você está presente nesta aula.</p>
                </div>
              ) : (
                <div className="text-center">
                  <Button onClick={markAttendance}>Marcar Presença</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default LiveClass;

