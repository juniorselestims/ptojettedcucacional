from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.lesson import Lesson
from src.services.zoom_service import ZoomService
from datetime import datetime

zoom_bp = Blueprint('zoom', __name__)
zoom_service = ZoomService()

@zoom_bp.route('/meetings', methods=['POST'])
@jwt_required()
def create_meeting():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    topic = data.get('topic')
    start_time_str = data.get('start_time')
    duration = data.get('duration', 60)
    description = data.get('description')
    lesson_id = data.get('lesson_id')
    
    if not topic or not start_time_str or not lesson_id:
        return jsonify({'message': 'Título, data/hora de início e ID da aula são obrigatórios'}), 400
    
    try:
        # Converter string de data/hora para objeto datetime
        start_time = datetime.fromisoformat(start_time_str.replace('Z', '+00:00'))
        
        # Criar reunião no Zoom
        meeting_data = zoom_service.create_meeting(topic, start_time, duration, description)
        
        # Atualizar a aula com os dados da reunião
        lesson = Lesson.query.get(lesson_id)
        if not lesson:
            return jsonify({'message': 'Aula não encontrada'}), 404
        
        lesson.live_id = meeting_data['id']
        db.session.commit()
        
        return jsonify({
            'message': 'Reunião criada com sucesso',
            'meeting': meeting_data
        }), 201
    
    except Exception as e:
        return jsonify({'message': f'Erro ao criar reunião: {str(e)}'}), 500

@zoom_bp.route('/meetings/<meeting_id>', methods=['GET'])
@jwt_required()
def get_meeting(meeting_id):
    try:
        meeting_data = zoom_service.get_meeting(meeting_id)
        return jsonify(meeting_data), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao obter reunião: {str(e)}'}), 500

@zoom_bp.route('/meetings/<meeting_id>', methods=['PUT'])
@jwt_required()
def update_meeting(meeting_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    topic = data.get('topic')
    start_time_str = data.get('start_time')
    duration = data.get('duration')
    description = data.get('description')
    
    try:
        # Converter string de data/hora para objeto datetime se fornecida
        start_time = None
        if start_time_str:
            start_time = datetime.fromisoformat(start_time_str.replace('Z', '+00:00'))
        
        # Atualizar reunião no Zoom
        meeting_data = zoom_service.update_meeting(
            meeting_id,
            topic=topic,
            start_time=start_time,
            duration=duration,
            description=description
        )
        
        return jsonify({
            'message': 'Reunião atualizada com sucesso',
            'meeting': meeting_data
        }), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao atualizar reunião: {str(e)}'}), 500

@zoom_bp.route('/meetings/<meeting_id>', methods=['DELETE'])
@jwt_required()
def delete_meeting(meeting_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    try:
        # Excluir reunião no Zoom
        success = zoom_service.delete_meeting(meeting_id)
        
        if success:
            # Atualizar aulas que usam esta reunião
            lessons = Lesson.query.filter_by(live_id=meeting_id).all()
            for lesson in lessons:
                lesson.live_id = None
            
            db.session.commit()
            
            return jsonify({'message': 'Reunião excluída com sucesso'}), 200
        else:
            return jsonify({'message': 'Falha ao excluir reunião'}), 500
    
    except Exception as e:
        return jsonify({'message': f'Erro ao excluir reunião: {str(e)}'}), 500

