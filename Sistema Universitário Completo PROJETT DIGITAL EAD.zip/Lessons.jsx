import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Plus, Pencil, Trash2, Video, Play, FileText } from 'lucide-react';

const Lessons = () => {
  const { currentUser } = useAuth();
  const [lessons, setLessons] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentLesson, setCurrentLesson] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    class_id: '',
    lesson_type: 'Video',
    video_url: '',
    live_id: '',
    lesson_date: ''
  });

  useEffect(() => {
    fetchLessons();
    fetchClasses();
  }, []);

  const fetchLessons = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/lessons');
      setLessons(response.data);
    } catch (error) {
      console.error('Erro ao buscar aulas:', error);
      setError('Não foi possível carregar as aulas. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchClasses = async () => {
    try {
      const response = await axios.get('/api/classes');
      setClasses(response.data);
    } catch (error) {
      console.error('Erro ao buscar turmas:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentLesson) {
        await axios.put(`/api/lessons/${currentLesson.id}`, formData);
      } else {
        await axios.post('/api/lessons', formData);
      }
      
      fetchLessons();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar aula:', error);
      setError(error.response?.data?.message || 'Erro ao salvar aula. Tente novamente.');
    }
  };

  const handleEdit = (lesson) => {
    setCurrentLesson(lesson);
    setFormData({
      title: lesson.title,
      class_id: lesson.class_id,
      lesson_type: lesson.lesson_type,
      video_url: lesson.video_url || '',
      live_id: lesson.live_id || '',
      lesson_date: lesson.lesson_date ? lesson.lesson_date.split('T')[0] : ''
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir esta aula?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/lessons/${id}`);
      fetchLessons();
    } catch (error) {
      console.error('Erro ao excluir aula:', error);
      setError(error.response?.data?.message || 'Erro ao excluir aula. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      class_id: '',
      lesson_type: 'Video',
      video_url: '',
      live_id: '',
      lesson_date: ''
    });
    setCurrentLesson(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const canManageLessons = ['Admin', 'Coordenador', 'Professor'].includes(currentUser.user_type);
  
  const videoLessons = lessons.filter(lesson => lesson.lesson_type === 'Video');
  const liveLessons = lessons.filter(lesson => lesson.lesson_type === 'Live');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Aulas</h1>
          <p className="text-gray-500">Acesse as aulas disponíveis</p>
        </div>
        
        {canManageLessons && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Aula
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Aula' : 'Nova Aula'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações da aula abaixo.' 
                    : 'Preencha as informações para criar uma nova aula.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Título da Aula</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="class_id">Turma</Label>
                  <select
                    id="class_id"
                    name="class_id"
                    value={formData.class_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione uma turma</option>
                    {classes.map(classItem => (
                      <option key={classItem.id} value={classItem.id}>
                        {classItem.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lesson_type">Tipo de Aula</Label>
                  <select
                    id="lesson_type"
                    name="lesson_type"
                    value={formData.lesson_type}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="Video">Videoaula</option>
                    <option value="Live">Aula ao Vivo</option>
                  </select>
                </div>
                
                {formData.lesson_type === 'Video' && (
                  <div className="space-y-2">
                    <Label htmlFor="video_url">URL do Vídeo</Label>
                    <Input
                      id="video_url"
                      name="video_url"
                      value={formData.video_url}
                      onChange={handleChange}
                      placeholder="https://www.youtube.com/watch?v=..."
                      required
                    />
                  </div>
                )}
                
                {formData.lesson_type === 'Live' && (
                  <div className="space-y-2">
                    <Label htmlFor="live_id">ID da Transmissão</Label>
                    <Input
                      id="live_id"
                      name="live_id"
                      value={formData.live_id}
                      onChange={handleChange}
                      placeholder="ID do Zoom, Google Meet, etc."
                      required
                    />
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="lesson_date">Data da Aula</Label>
                  <Input
                    id="lesson_date"
                    name="lesson_date"
                    type="date"
                    value={formData.lesson_date}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Criar Aula'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">Todas as Aulas</TabsTrigger>
          <TabsTrigger value="video">Videoaulas</TabsTrigger>
          <TabsTrigger value="live">Aulas ao Vivo</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Todas as Aulas</CardTitle>
              <CardDescription>Lista completa de aulas disponíveis</CardDescription>
            </CardHeader>
            <CardContent>
              {renderLessonsTable(lessons)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="video" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Videoaulas</CardTitle>
              <CardDescription>Aulas gravadas disponíveis para assistir a qualquer momento</CardDescription>
            </CardHeader>
            <CardContent>
              {renderLessonsTable(videoLessons)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="live" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Aulas ao Vivo</CardTitle>
              <CardDescription>Aulas transmitidas em tempo real</CardDescription>
            </CardHeader>
            <CardContent>
              {renderLessonsTable(liveLessons)}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
  
  function renderLessonsTable(lessonsData) {
    if (loading) {
      return (
        <div className="flex justify-center p-4">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      );
    }
    
    if (lessonsData.length === 0) {
      return <p className="text-center text-gray-500 py-4">Nenhuma aula encontrada.</p>;
    }
    
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Título</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Data</TableHead>
              <TableHead>Turma</TableHead>
              <TableHead className="w-24">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {lessonsData.map(lesson => (
              <TableRow key={lesson.id}>
                <TableCell className="font-medium">{lesson.title}</TableCell>
                <TableCell>
                  {lesson.lesson_type === 'Video' ? (
                    <div className="flex items-center">
                      <Video className="h-4 w-4 mr-1 text-blue-500" />
                      <span>Videoaula</span>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <Play className="h-4 w-4 mr-1 text-red-500" />
                      <span>Aula ao Vivo</span>
                    </div>
                  )}
                </TableCell>
                <TableCell>
                  {lesson.lesson_date ? new Date(lesson.lesson_date).toLocaleDateString('pt-BR') : 'Não definida'}
                </TableCell>
                <TableCell>{lesson.class_name || `Turma ${lesson.class_id}`}</TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <Link to={`/lessons/${lesson.id}`}>
                      <Button variant="ghost" size="icon">
                        <FileText className="h-4 w-4" />
                      </Button>
                    </Link>
                    {canManageLessons && (
                      <>
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(lesson)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(lesson.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }
};

export default Lessons;

