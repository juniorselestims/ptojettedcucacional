import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Plus, Pencil, Trash2, FileText, Clock } from 'lucide-react';

const Assessments = () => {
  const { currentUser } = useAuth();
  const [assessments, setAssessments] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentAssessment, setCurrentAssessment] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    class_id: '',
    assessment_type: 'Objetiva',
    due_date: ''
  });

  useEffect(() => {
    fetchAssessments();
    fetchClasses();
  }, []);

  const fetchAssessments = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/assessments');
      setAssessments(response.data);
    } catch (error) {
      console.error('Erro ao buscar avaliações:', error);
      setError('Não foi possível carregar as avaliações. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchClasses = async () => {
    try {
      const response = await axios.get('/api/classes');
      setClasses(response.data);
    } catch (error) {
      console.error('Erro ao buscar turmas:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentAssessment) {
        await axios.put(`/api/assessments/${currentAssessment.id}`, formData);
      } else {
        await axios.post('/api/assessments', formData);
      }
      
      fetchAssessments();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar avaliação:', error);
      setError(error.response?.data?.message || 'Erro ao salvar avaliação. Tente novamente.');
    }
  };

  const handleEdit = (assessment) => {
    setCurrentAssessment(assessment);
    setFormData({
      title: assessment.title,
      class_id: assessment.class_id,
      assessment_type: assessment.assessment_type,
      due_date: assessment.due_date ? assessment.due_date.split('T')[0] : ''
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir esta avaliação?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/assessments/${id}`);
      fetchAssessments();
    } catch (error) {
      console.error('Erro ao excluir avaliação:', error);
      setError(error.response?.data?.message || 'Erro ao excluir avaliação. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      class_id: '',
      assessment_type: 'Objetiva',
      due_date: ''
    });
    setCurrentAssessment(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const canManageAssessments = ['Admin', 'Coordenador', 'Professor'].includes(currentUser.user_type);
  
  // Filtrar avaliações por status
  const pendingAssessments = assessments.filter(assessment => {
    const dueDate = assessment.due_date ? new Date(assessment.due_date) : null;
    return dueDate && dueDate > new Date();
  });
  
  const completedAssessments = assessments.filter(assessment => {
    // Simulando avaliações concluídas
    return assessment.id % 2 === 0;
  });

  const getAssessmentTypeBadge = (type) => {
    switch (type) {
      case 'Objetiva':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Objetiva</Badge>;
      case 'Dissertativa':
        return <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">Dissertativa</Badge>;
      case 'Múltipla Escolha':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Múltipla Escolha</Badge>;
      default:
        return <Badge variant="outline">{type}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Avaliações</h1>
          <p className="text-gray-500">Gerencie as avaliações das disciplinas</p>
        </div>
        
        {canManageAssessments && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Avaliação
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Avaliação' : 'Nova Avaliação'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações da avaliação abaixo.' 
                    : 'Preencha as informações para criar uma nova avaliação.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Título da Avaliação</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="class_id">Turma</Label>
                  <select
                    id="class_id"
                    name="class_id"
                    value={formData.class_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione uma turma</option>
                    {classes.map(classItem => (
                      <option key={classItem.id} value={classItem.id}>
                        {classItem.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="assessment_type">Tipo de Avaliação</Label>
                  <select
                    id="assessment_type"
                    name="assessment_type"
                    value={formData.assessment_type}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="Objetiva">Objetiva</option>
                    <option value="Dissertativa">Dissertativa</option>
                    <option value="Múltipla Escolha">Múltipla Escolha</option>
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="due_date">Data de Entrega</Label>
                  <Input
                    id="due_date"
                    name="due_date"
                    type="date"
                    value={formData.due_date}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Criar Avaliação'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">Todas</TabsTrigger>
          <TabsTrigger value="pending">Pendentes</TabsTrigger>
          <TabsTrigger value="completed">Concluídas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Todas as Avaliações</CardTitle>
              <CardDescription>Lista completa de avaliações</CardDescription>
            </CardHeader>
            <CardContent>
              {renderAssessmentsTable(assessments)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="pending" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Avaliações Pendentes</CardTitle>
              <CardDescription>Avaliações que ainda não foram concluídas</CardDescription>
            </CardHeader>
            <CardContent>
              {renderAssessmentsTable(pendingAssessments)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="completed" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Avaliações Concluídas</CardTitle>
              <CardDescription>Avaliações que já foram realizadas</CardDescription>
            </CardHeader>
            <CardContent>
              {renderAssessmentsTable(completedAssessments)}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
  
  function renderAssessmentsTable(assessmentsData) {
    if (loading) {
      return (
        <div className="flex justify-center p-4">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      );
    }
    
    if (assessmentsData.length === 0) {
      return <p className="text-center text-gray-500 py-4">Nenhuma avaliação encontrada.</p>;
    }
    
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Título</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Turma</TableHead>
              <TableHead>Data de Entrega</TableHead>
              <TableHead className="w-24">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assessmentsData.map(assessment => (
              <TableRow key={assessment.id}>
                <TableCell className="font-medium">{assessment.title}</TableCell>
                <TableCell>{getAssessmentTypeBadge(assessment.assessment_type)}</TableCell>
                <TableCell>
                  {classes.find(c => c.id === assessment.class_id)?.name || `Turma ${assessment.class_id}`}
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-gray-500" />
                    {assessment.due_date 
                      ? new Date(assessment.due_date).toLocaleDateString('pt-BR') 
                      : 'Não definida'}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <Link to={`/assessments/${assessment.id}`}>
                      <Button variant="ghost" size="icon">
                        <FileText className="h-4 w-4" />
                      </Button>
                    </Link>
                    {canManageAssessments && (
                      <>
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(assessment)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(assessment.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }
};

export default Assessments;

