from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.financial import Invoice
from src.services.payment_service import PaymentService
from src.services.notification_service import NotificationService

payment_bp = Blueprint('payment', __name__)
payment_service = PaymentService()
notification_service = NotificationService()

@payment_bp.route('/boleto/<int:invoice_id>', methods=['POST'])
@jwt_required()
def generate_boleto(invoice_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    # Verificar se o usuário tem acesso à fatura
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return jsonify({'message': 'Fatura não encontrada'}), 404
    
    if user.user_type not in ['Admin', 'Financeiro'] and invoice.student_id != current_user_id:
        return jsonify({'message': 'Acesso negado'}), 403
    
    try:
        # Gerar boleto
        boleto_data = payment_service.generate_boleto(invoice)
        
        return jsonify({
            'message': 'Boleto gerado com sucesso',
            'boleto': boleto_data
        }), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao gerar boleto: {str(e)}'}), 500

@payment_bp.route('/pix/<int:invoice_id>', methods=['POST'])
@jwt_required()
def generate_pix(invoice_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    # Verificar se o usuário tem acesso à fatura
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return jsonify({'message': 'Fatura não encontrada'}), 404
    
    if user.user_type not in ['Admin', 'Financeiro'] and invoice.student_id != current_user_id:
        return jsonify({'message': 'Acesso negado'}), 403
    
    try:
        # Gerar PIX
        pix_data = payment_service.generate_pix(invoice)
        
        return jsonify({
            'message': 'PIX gerado com sucesso',
            'pix': pix_data
        }), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao gerar PIX: {str(e)}'}), 500

@payment_bp.route('/credit-card/<int:invoice_id>', methods=['POST'])
@jwt_required()
def process_credit_card(invoice_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    # Verificar se o usuário tem acesso à fatura
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return jsonify({'message': 'Fatura não encontrada'}), 404
    
    if user.user_type not in ['Admin', 'Financeiro'] and invoice.student_id != current_user_id:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    card_data = data.get('card_data')
    
    if not card_data:
        return jsonify({'message': 'Dados do cartão são obrigatórios'}), 400
    
    try:
        # Processar pagamento com cartão de crédito
        payment_data = payment_service.process_credit_card(invoice, card_data)
        
        # Se o pagamento foi aprovado, atualizar o status da fatura
        if payment_data['status'] == 'approved':
            invoice.status = 'Pago'
            db.session.commit()
        
        return jsonify({
            'message': 'Pagamento processado com sucesso',
            'payment': payment_data
        }), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao processar pagamento: {str(e)}'}), 500

@payment_bp.route('/status/<payment_id>', methods=['GET'])
@jwt_required()
def check_payment_status(payment_id):
    try:
        # Verificar status do pagamento
        status_data = payment_service.check_payment_status(payment_id)
        
        return jsonify(status_data), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao verificar status do pagamento: {str(e)}'}), 500

@payment_bp.route('/refund/<payment_id>', methods=['POST'])
@jwt_required()
def refund_payment(payment_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    try:
        # Realizar estorno
        refund_data = payment_service.refund_payment(payment_id)
        
        return jsonify({
            'message': 'Estorno realizado com sucesso',
            'refund': refund_data
        }), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao realizar estorno: {str(e)}'}), 500

@payment_bp.route('/reminder/<int:invoice_id>', methods=['POST'])
@jwt_required()
def send_payment_reminder(invoice_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    # Verificar se a fatura existe
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return jsonify({'message': 'Fatura não encontrada'}), 404
    
    # Obter o usuário (aluno) da fatura
    student = User.query.get(invoice.student_id)
    if not student:
        return jsonify({'message': 'Aluno não encontrado'}), 404
    
    try:
        # Enviar lembrete de pagamento
        result = notification_service.send_payment_reminder(invoice, student)
        
        return jsonify({
            'message': 'Lembrete de pagamento enviado com sucesso',
            'result': result
        }), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao enviar lembrete de pagamento: {str(e)}'}), 500

