from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.financial import TuitionPlan, Invoice, db
from src.models.user import User
from datetime import datetime

financial_bp = Blueprint('financial', __name__)

# Rotas para Planos de Mensalidades
@financial_bp.route('/tuition-plans', methods=['GET'])
@jwt_required()
def get_tuition_plans():
    tuition_plans = TuitionPlan.query.all()
    return jsonify([{
        'id': plan.id,
        'name': plan.name,
        'value': plan.value
    } for plan in tuition_plans]), 200

@financial_bp.route('/tuition-plans/<int:plan_id>', methods=['GET'])
@jwt_required()
def get_tuition_plan(plan_id):
    plan = TuitionPlan.query.get(plan_id)
    if not plan:
        return jsonify({'message': 'Plano de mensalidade não encontrado'}), 404
    
    return jsonify({
        'id': plan.id,
        'name': plan.name,
        'value': plan.value
    }), 200

@financial_bp.route('/tuition-plans', methods=['POST'])
@jwt_required()
def create_tuition_plan():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    name = data.get('name')
    value = data.get('value')
    
    if not name or value is None:
        return jsonify({'message': 'Nome e valor são obrigatórios'}), 400
    
    new_plan = TuitionPlan(
        name=name,
        value=value
    )
    
    db.session.add(new_plan)
    db.session.commit()
    
    return jsonify({'message': 'Plano de mensalidade criado com sucesso', 'id': new_plan.id}), 201

@financial_bp.route('/tuition-plans/<int:plan_id>', methods=['PUT'])
@jwt_required()
def update_tuition_plan(plan_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    plan = TuitionPlan.query.get(plan_id)
    if not plan:
        return jsonify({'message': 'Plano de mensalidade não encontrado'}), 404
    
    data = request.get_json()
    plan.name = data.get('name', plan.name)
    plan.value = data.get('value', plan.value)
    
    db.session.commit()
    
    return jsonify({'message': 'Plano de mensalidade atualizado com sucesso'}), 200

@financial_bp.route('/tuition-plans/<int:plan_id>', methods=['DELETE'])
@jwt_required()
def delete_tuition_plan(plan_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    plan = TuitionPlan.query.get(plan_id)
    if not plan:
        return jsonify({'message': 'Plano de mensalidade não encontrado'}), 404
    
    db.session.delete(plan)
    db.session.commit()
    
    return jsonify({'message': 'Plano de mensalidade excluído com sucesso'}), 200

# Rotas para Boletos
@financial_bp.route('/invoices', methods=['GET'])
@jwt_required()
def get_invoices():
    student_id = request.args.get('student_id')
    status = request.args.get('status')
    
    query = Invoice.query
    
    if student_id:
        query = query.filter_by(student_id=student_id)
    
    if status:
        query = query.filter_by(status=status)
    
    invoices = query.all()
    
    return jsonify([{
        'id': invoice.id,
        'student_id': invoice.student_id,
        'plan_id': invoice.plan_id,
        'value': invoice.value,
        'due_date': invoice.due_date.isoformat() if invoice.due_date else None,
        'status': invoice.status
    } for invoice in invoices]), 200

@financial_bp.route('/invoices/<int:invoice_id>', methods=['GET'])
@jwt_required()
def get_invoice(invoice_id):
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return jsonify({'message': 'Boleto não encontrado'}), 404
    
    return jsonify({
        'id': invoice.id,
        'student_id': invoice.student_id,
        'plan_id': invoice.plan_id,
        'value': invoice.value,
        'due_date': invoice.due_date.isoformat() if invoice.due_date else None,
        'status': invoice.status
    }), 200

@financial_bp.route('/invoices', methods=['POST'])
@jwt_required()
def create_invoice():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    student_id = data.get('student_id')
    plan_id = data.get('plan_id')
    value = data.get('value')
    due_date = data.get('due_date')
    status = data.get('status', 'Pendente')
    
    if not student_id or not plan_id or value is None or not due_date:
        return jsonify({'message': 'ID do aluno, ID do plano, valor e data de vencimento são obrigatórios'}), 400
    
    # Converter string de data para datetime
    try:
        parsed_date = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
    except ValueError:
        return jsonify({'message': 'Formato de data inválido'}), 400
    
    new_invoice = Invoice(
        student_id=student_id,
        plan_id=plan_id,
        value=value,
        due_date=parsed_date,
        status=status
    )
    
    db.session.add(new_invoice)
    db.session.commit()
    
    return jsonify({'message': 'Boleto criado com sucesso', 'id': new_invoice.id}), 201

@financial_bp.route('/invoices/<int:invoice_id>', methods=['PUT'])
@jwt_required()
def update_invoice(invoice_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return jsonify({'message': 'Boleto não encontrado'}), 404
    
    data = request.get_json()
    invoice.student_id = data.get('student_id', invoice.student_id)
    invoice.plan_id = data.get('plan_id', invoice.plan_id)
    invoice.value = data.get('value', invoice.value)
    invoice.status = data.get('status', invoice.status)
    
    due_date = data.get('due_date')
    if due_date:
        try:
            invoice.due_date = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
        except ValueError:
            return jsonify({'message': 'Formato de data inválido'}), 400
    
    db.session.commit()
    
    return jsonify({'message': 'Boleto atualizado com sucesso'}), 200

@financial_bp.route('/invoices/<int:invoice_id>', methods=['DELETE'])
@jwt_required()
def delete_invoice(invoice_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Financeiro']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return jsonify({'message': 'Boleto não encontrado'}), 404
    
    db.session.delete(invoice)
    db.session.commit()
    
    return jsonify({'message': 'Boleto excluído com sucesso'}), 200

