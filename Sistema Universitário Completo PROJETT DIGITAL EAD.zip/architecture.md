# Arquitetura do Sistema PROJETT DIGITAL EAD

## 1. Visão Geral

A arquitetura do sistema será baseada em uma abordagem de microsserviços, com um backend responsável pela lógica de negócio e APIs REST, um frontend reativo para a interface do usuário e um banco de dados relacional para persistência dos dados.

## 2. Tecnologias

*   **Frontend:** React.js com TailwindCSS para estilização.
*   **Backend:** Node.js com o framework Express.js.
*   **Banco de Dados:** PostgreSQL.
*   **Streaming de Vídeo:** Integração com a API do Zoom para aulas ao vivo.
*   **Pagamentos:** Integração com as APIs do Mercado Pago e PayPal.

## 3. Diagrama da Arquitetura

(Será criado um diagrama visual para representar a arquitetura)

## 4. Componentes

### 4.1. Frontend (React.js)

*   **Componentes de UI:** Serão desenvolvidos componentes reutilizáveis para os elementos da interface, como botões, formulários, tabelas, etc.
*   **Gerenciamento de Estado:** Utilização do Redux ou Context API do React para gerenciar o estado da aplicação.
*   **Roteamento:** O React Router será utilizado para gerenciar as rotas da aplicação.
*   **Comunicação com o Backend:** A comunicação com o backend será feita através de requisições HTTP para as APIs REST.

### 4.2. Backend (Node.js + Express.js)

*   **API REST:** Serão desenvolvidas APIs RESTful para expor as funcionalidades do sistema.
*   **Autenticação e Autorização:** Implementação de um sistema de autenticação baseado em tokens (JWT) e um sistema de autorização baseado em papéis (roles).
*   **ORM (Object-Relational Mapping):** Utilização do Sequelize ou TypeORM para mapear os objetos do sistema para as tabelas do banco de dados.
*   **Microsserviços (Opcional):** Dependendo da complexidade, a arquitetura pode ser dividida em microsserviços para funcionalidades específicas (ex: serviço de notificações, serviço de pagamentos).

### 4.3. Banco de Dados (PostgreSQL)

*   **Esquema do Banco de Dados:** O esquema do banco de dados será projetado para refletir as entidades do sistema e seus relacionamentos.
*   **Tabelas:** Serão criadas tabelas para armazenar informações sobre usuários, cursos, disciplinas, turmas, matrículas, notas, pagamentos, etc.

### 4.4. Integrações

*   **Zoom API:** Para agendamento e gerenciamento de aulas ao vivo.
*   **Mercado Pago/PayPal API:** Para processamento de pagamentos.
*   **Serviço de E-mail/WhatsApp:** Para envio de notificações e lembretes.

