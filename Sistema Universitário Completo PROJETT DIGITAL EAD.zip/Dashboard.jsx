import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  BookOpen, 
  Video, 
  FileText, 
  DollarSign, 
  Library, 
  LifeBuoy 
} from 'lucide-react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

const Dashboard = () => {
  const { currentUser } = useAuth();
  const [stats, setStats] = useState({
    users: 0,
    courses: 0,
    disciplines: 0,
    classes: 0,
    lessons: 0,
    assessments: 0,
    books: 0,
    tickets: 0,
    invoices: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Em um sistema real, faríamos chamadas à API para obter estatísticas
    // Aqui estamos simulando dados para demonstração
    const fetchStats = async () => {
      try {
        setLoading(true);
        // Simulando dados para demonstração
        setStats({
          users: 120,
          courses: 15,
          disciplines: 45,
          classes: 30,
          lessons: 250,
          assessments: 180,
          books: 320,
          tickets: 25,
          invoices: 95
        });
      } catch (error) {
        console.error('Erro ao buscar estatísticas:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const pieData = {
    labels: ['Alunos', 'Professores', 'Coordenadores', 'Financeiro', 'Suporte', 'Admin'],
    datasets: [
      {
        data: [100, 10, 3, 2, 3, 2],
        backgroundColor: [
          '#3b82f6',
          '#10b981',
          '#f59e0b',
          '#ef4444',
          '#8b5cf6',
          '#6366f1',
        ],
      },
    ],
  };

  const barData = {
    labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
    datasets: [
      {
        label: 'Aulas Assistidas',
        data: [65, 59, 80, 81, 56, 55],
        backgroundColor: '#3b82f6',
      },
      {
        label: 'Avaliações Realizadas',
        data: [28, 48, 40, 19, 86, 27],
        backgroundColor: '#10b981',
      },
    ],
  };

  const renderUserDashboard = () => {
    if (currentUser.user_type === 'Aluno') {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Minhas Aulas</CardTitle>
              <CardDescription>Aulas disponíveis e assistidas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">24/36</p>
                  <p className="text-sm text-gray-500">Aulas assistidas</p>
                </div>
                <Video className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Minhas Avaliações</CardTitle>
              <CardDescription>Avaliações pendentes e concluídas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">8/12</p>
                  <p className="text-sm text-gray-500">Avaliações concluídas</p>
                </div>
                <FileText className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Financeiro</CardTitle>
              <CardDescription>Status dos pagamentos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">2</p>
                  <p className="text-sm text-gray-500">Boletos pendentes</p>
                </div>
                <DollarSign className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Usuários</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">{stats.users}</p>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Cursos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">{stats.courses}</p>
              <BookOpen className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Aulas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">{stats.lessons}</p>
              <Video className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Chamados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">{stats.tickets}</p>
              <LifeBuoy className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-gray-500">Bem-vindo, {currentUser.name}!</p>
      </div>
      
      {renderUserDashboard()}
      
      {currentUser.user_type !== 'Aluno' && (
        <Tabs defaultValue="stats" className="mt-6">
          <TabsList>
            <TabsTrigger value="stats">Estatísticas</TabsTrigger>
            <TabsTrigger value="users">Usuários</TabsTrigger>
            <TabsTrigger value="activity">Atividade</TabsTrigger>
          </TabsList>
          <TabsContent value="stats" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Distribuição de Usuários</CardTitle>
                  <CardDescription>Por tipo de usuário</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <Pie data={pieData} options={{ maintainAspectRatio: false }} />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Atividade Mensal</CardTitle>
                  <CardDescription>Últimos 6 meses</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <Bar 
                      data={barData} 
                      options={{ 
                        maintainAspectRatio: false,
                        scales: {
                          y: {
                            beginAtZero: true
                          }
                        }
                      }} 
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="users" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Usuários Recentes</CardTitle>
                <CardDescription>Últimos usuários cadastrados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap">João Silva</td>
                        <td className="px-6 py-4 whitespace-nowrap">joao@email.com</td>
                        <td className="px-6 py-4 whitespace-nowrap">Aluno</td>
                        <td className="px-6 py-4 whitespace-nowrap">15/08/2025</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap">Maria Santos</td>
                        <td className="px-6 py-4 whitespace-nowrap">maria@email.com</td>
                        <td className="px-6 py-4 whitespace-nowrap">Aluno</td>
                        <td className="px-6 py-4 whitespace-nowrap">14/08/2025</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap">Pedro Oliveira</td>
                        <td className="px-6 py-4 whitespace-nowrap">pedro@email.com</td>
                        <td className="px-6 py-4 whitespace-nowrap">Professor</td>
                        <td className="px-6 py-4 whitespace-nowrap">12/08/2025</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="activity" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Atividades Recentes</CardTitle>
                <CardDescription>Últimas ações no sistema</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="mr-4 mt-0.5">
                      <Video className="h-5 w-5 text-blue-500" />
                    </div>
                    <div>
                      <p className="font-medium">Nova aula adicionada</p>
                      <p className="text-sm text-gray-500">Introdução à Programação - Prof. Carlos</p>
                      <p className="text-xs text-gray-400">Hoje, 10:30</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="mr-4 mt-0.5">
                      <FileText className="h-5 w-5 text-green-500" />
                    </div>
                    <div>
                      <p className="font-medium">Nova avaliação criada</p>
                      <p className="text-sm text-gray-500">Prova Final - Matemática Discreta</p>
                      <p className="text-xs text-gray-400">Ontem, 15:45</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="mr-4 mt-0.5">
                      <Users className="h-5 w-5 text-purple-500" />
                    </div>
                    <div>
                      <p className="font-medium">Novo aluno matriculado</p>
                      <p className="text-sm text-gray-500">Ana Souza - Curso de Administração</p>
                      <p className="text-xs text-gray-400">19/08/2025, 09:15</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="mr-4 mt-0.5">
                      <DollarSign className="h-5 w-5 text-yellow-500" />
                    </div>
                    <div>
                      <p className="font-medium">Pagamento recebido</p>
                      <p className="text-sm text-gray-500">Mensalidade - Roberto Almeida</p>
                      <p className="text-xs text-gray-400">18/08/2025, 14:20</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
};

export default Dashboard;

