from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.course import Course, db
from src.models.user import User

course_bp = Blueprint('course', __name__)

@course_bp.route('/courses', methods=['GET'])
@jwt_required()
def get_courses():
    courses = Course.query.all()
    return jsonify([{
        'id': course.id,
        'name': course.name,
        'description': course.description,
        'coordinator_id': course.coordinator_id
    } for course in courses]), 200

@course_bp.route('/courses/<int:course_id>', methods=['GET'])
@jwt_required()
def get_course(course_id):
    course = Course.query.get(course_id)
    if not course:
        return jsonify({'message': 'Curso não encontrado'}), 404
    
    return jsonify({
        'id': course.id,
        'name': course.name,
        'description': course.description,
        'coordinator_id': course.coordinator_id
    }), 200

@course_bp.route('/courses', methods=['POST'])
@jwt_required()
def create_course():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    name = data.get('name')
    description = data.get('description')
    coordinator_id = data.get('coordinator_id')
    
    if not name:
        return jsonify({'message': 'Nome do curso é obrigatório'}), 400
    
    new_course = Course(
        name=name,
        description=description,
        coordinator_id=coordinator_id
    )
    
    db.session.add(new_course)
    db.session.commit()
    
    return jsonify({'message': 'Curso criado com sucesso', 'id': new_course.id}), 201

@course_bp.route('/courses/<int:course_id>', methods=['PUT'])
@jwt_required()
def update_course(course_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    course = Course.query.get(course_id)
    if not course:
        return jsonify({'message': 'Curso não encontrado'}), 404
    
    data = request.get_json()
    course.name = data.get('name', course.name)
    course.description = data.get('description', course.description)
    course.coordinator_id = data.get('coordinator_id', course.coordinator_id)
    
    db.session.commit()
    
    return jsonify({'message': 'Curso atualizado com sucesso'}), 200

@course_bp.route('/courses/<int:course_id>', methods=['DELETE'])
@jwt_required()
def delete_course(course_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type != 'Admin':
        return jsonify({'message': 'Acesso negado'}), 403
    
    course = Course.query.get(course_id)
    if not course:
        return jsonify({'message': 'Curso não encontrado'}), 404
    
    db.session.delete(course)
    db.session.commit()
    
    return jsonify({'message': 'Curso excluído com sucesso'}), 200

