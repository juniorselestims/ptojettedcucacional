from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.lesson import Lesson
from src.models.enrollment import Enrollment
from src.services.notification_service import NotificationService

notification_bp = Blueprint('notification', __name__)
notification_service = NotificationService()

@notification_bp.route('/notify-lesson/<int:lesson_id>', methods=['POST'])
@jwt_required()
def notify_lesson(lesson_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    # Verificar se a aula existe
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({'message': 'Aula não encontrada'}), 404
    
    try:
        # Obter todos os alunos matriculados na turma da aula
        enrollments = Enrollment.query.filter_by(class_id=lesson.class_id).all()
        student_ids = [enrollment.student_id for enrollment in enrollments]
        students = User.query.filter(User.id.in_(student_ids)).all()
        
        # Enviar notificação para os alunos
        result = notification_service.send_new_lesson_notification(lesson, students)
        
        return jsonify({
            'message': 'Notificações enviadas com sucesso',
            'result': result
        }), 200
    
    except Exception as e:
        return jsonify({'message': f'Erro ao enviar notificações: {str(e)}'}), 500

@notification_bp.route('/email', methods=['POST'])
@jwt_required()
def send_email():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor', 'Suporte']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    recipient = data.get('recipient')
    subject = data.get('subject')
    message = data.get('message')
    html_message = data.get('html_message')
    
    if not recipient or not subject or not message:
        return jsonify({'message': 'Destinatário, assunto e mensagem são obrigatórios'}), 400
    
    try:
        # Enviar e-mail
        success = notification_service.send_email(recipient, subject, message, html_message)
        
        if success:
            return jsonify({'message': 'E-mail enviado com sucesso'}), 200
        else:
            return jsonify({'message': 'Falha ao enviar e-mail'}), 500
    
    except Exception as e:
        return jsonify({'message': f'Erro ao enviar e-mail: {str(e)}'}), 500

@notification_bp.route('/whatsapp', methods=['POST'])
@jwt_required()
def send_whatsapp():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if user.user_type not in ['Admin', 'Coordenador', 'Professor', 'Suporte']:
        return jsonify({'message': 'Acesso negado'}), 403
    
    data = request.get_json()
    phone_number = data.get('phone_number')
    message = data.get('message')
    
    if not phone_number or not message:
        return jsonify({'message': 'Número de telefone e mensagem são obrigatórios'}), 400
    
    try:
        # Enviar WhatsApp
        success = notification_service.send_whatsapp(phone_number, message)
        
        if success:
            return jsonify({'message': 'Mensagem de WhatsApp enviada com sucesso'}), 200
        else:
            return jsonify({'message': 'Falha ao enviar mensagem de WhatsApp'}), 500
    
    except Exception as e:
        return jsonify({'message': f'Erro ao enviar mensagem de WhatsApp: {str(e)}'}), 500

