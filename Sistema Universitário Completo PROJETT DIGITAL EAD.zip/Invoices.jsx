import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Plus, Pencil, Trash2, Download, CreditCard, DollarSign } from 'lucide-react';

const Invoices = () => {
  const { currentUser } = useAuth();
  const [invoices, setInvoices] = useState([]);
  const [students, setStudents] = useState([]);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentInvoice, setCurrentInvoice] = useState(null);
  const [formData, setFormData] = useState({
    student_id: '',
    plan_id: '',
    value: '',
    due_date: '',
    status: 'Pendente'
  });

  useEffect(() => {
    fetchInvoices();
    if (['Admin', 'Financeiro'].includes(currentUser.user_type)) {
      fetchStudents();
      fetchPlans();
    }
  }, [currentUser]);

  const fetchInvoices = async () => {
    try {
      setLoading(true);
      let url = '/api/invoices';
      
      // Se for aluno, buscar apenas os boletos do próprio aluno
      if (currentUser.user_type === 'Aluno') {
        url += `?student_id=${currentUser.id}`;
      }
      
      const response = await axios.get(url);
      setInvoices(response.data);
    } catch (error) {
      console.error('Erro ao buscar boletos:', error);
      setError('Não foi possível carregar os boletos. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  const fetchStudents = async () => {
    try {
      const response = await axios.get('/api/users?user_type=Aluno');
      setStudents(response.data);
    } catch (error) {
      console.error('Erro ao buscar alunos:', error);
    }
  };

  const fetchPlans = async () => {
    try {
      const response = await axios.get('/api/tuition-plans');
      setPlans(response.data);
    } catch (error) {
      console.error('Erro ao buscar planos:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      
      if (isEditMode && currentInvoice) {
        await axios.put(`/api/invoices/${currentInvoice.id}`, formData);
      } else {
        await axios.post('/api/invoices', formData);
      }
      
      fetchInvoices();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Erro ao salvar boleto:', error);
      setError(error.response?.data?.message || 'Erro ao salvar boleto. Tente novamente.');
    }
  };

  const handleEdit = (invoice) => {
    setCurrentInvoice(invoice);
    setFormData({
      student_id: invoice.student_id,
      plan_id: invoice.plan_id,
      value: invoice.value,
      due_date: invoice.due_date ? invoice.due_date.split('T')[0] : '',
      status: invoice.status
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Tem certeza que deseja excluir este boleto?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/invoices/${id}`);
      fetchInvoices();
    } catch (error) {
      console.error('Erro ao excluir boleto:', error);
      setError(error.response?.data?.message || 'Erro ao excluir boleto. Tente novamente.');
    }
  };

  const handlePayment = async (id) => {
    try {
      await axios.put(`/api/invoices/${id}`, { status: 'Pago' });
      fetchInvoices();
    } catch (error) {
      console.error('Erro ao processar pagamento:', error);
      setError(error.response?.data?.message || 'Erro ao processar pagamento. Tente novamente.');
    }
  };

  const resetForm = () => {
    setFormData({
      student_id: '',
      plan_id: '',
      value: '',
      due_date: '',
      status: 'Pendente'
    });
    setCurrentInvoice(null);
    setIsEditMode(false);
  };

  const handleDialogOpen = (open) => {
    setIsDialogOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const canManageInvoices = ['Admin', 'Financeiro'].includes(currentUser.user_type);
  
  const pendingInvoices = invoices.filter(invoice => invoice.status === 'Pendente');
  const paidInvoices = invoices.filter(invoice => invoice.status === 'Pago');
  const overdueInvoices = invoices.filter(invoice => invoice.status === 'Atrasado');

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pendente':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pendente</Badge>;
      case 'Pago':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Pago</Badge>;
      case 'Atrasado':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Atrasado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Financeiro</h1>
          <p className="text-gray-500">
            {currentUser.user_type === 'Aluno' 
              ? 'Gerencie seus pagamentos e mensalidades' 
              : 'Gerencie os pagamentos e mensalidades dos alunos'}
          </p>
        </div>
        
        {canManageInvoices && (
          <Dialog open={isDialogOpen} onOpenChange={handleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Boleto
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{isEditMode ? 'Editar Boleto' : 'Novo Boleto'}</DialogTitle>
                <DialogDescription>
                  {isEditMode 
                    ? 'Edite as informações do boleto abaixo.' 
                    : 'Preencha as informações para criar um novo boleto.'}
                </DialogDescription>
              </DialogHeader>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="student_id">Aluno</Label>
                  <select
                    id="student_id"
                    name="student_id"
                    value={formData.student_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione um aluno</option>
                    {students.map(student => (
                      <option key={student.id} value={student.id}>
                        {student.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="plan_id">Plano</Label>
                  <select
                    id="plan_id"
                    name="plan_id"
                    value={formData.plan_id}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="">Selecione um plano</option>
                    {plans.map(plan => (
                      <option key={plan.id} value={plan.id}>
                        {plan.name} - R$ {plan.value}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="value">Valor (R$)</Label>
                  <Input
                    id="value"
                    name="value"
                    type="number"
                    step="0.01"
                    value={formData.value}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="due_date">Data de Vencimento</Label>
                  <Input
                    id="due_date"
                    name="due_date"
                    type="date"
                    value={formData.due_date}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    className="w-full rounded-md border border-gray-300 p-2"
                    required
                  >
                    <option value="Pendente">Pendente</option>
                    <option value="Pago">Pago</option>
                    <option value="Atrasado">Atrasado</option>
                  </select>
                </div>
                
                <DialogFooter>
                  <Button type="submit">
                    {isEditMode ? 'Salvar Alterações' : 'Criar Boleto'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">Todos</TabsTrigger>
          <TabsTrigger value="pending">Pendentes</TabsTrigger>
          <TabsTrigger value="paid">Pagos</TabsTrigger>
          <TabsTrigger value="overdue">Atrasados</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Todos os Boletos</CardTitle>
              <CardDescription>Lista completa de boletos</CardDescription>
            </CardHeader>
            <CardContent>
              {renderInvoicesTable(invoices)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="pending" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Boletos Pendentes</CardTitle>
              <CardDescription>Boletos aguardando pagamento</CardDescription>
            </CardHeader>
            <CardContent>
              {renderInvoicesTable(pendingInvoices)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="paid" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Boletos Pagos</CardTitle>
              <CardDescription>Boletos com pagamento confirmado</CardDescription>
            </CardHeader>
            <CardContent>
              {renderInvoicesTable(paidInvoices)}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="overdue" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Boletos Atrasados</CardTitle>
              <CardDescription>Boletos com pagamento em atraso</CardDescription>
            </CardHeader>
            <CardContent>
              {renderInvoicesTable(overdueInvoices)}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
  
  function renderInvoicesTable(invoicesData) {
    if (loading) {
      return (
        <div className="flex justify-center p-4">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      );
    }
    
    if (invoicesData.length === 0) {
      return <p className="text-center text-gray-500 py-4">Nenhum boleto encontrado.</p>;
    }
    
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {currentUser.user_type !== 'Aluno' && <TableHead>Aluno</TableHead>}
              <TableHead>Plano</TableHead>
              <TableHead>Valor</TableHead>
              <TableHead>Vencimento</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-24">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoicesData.map(invoice => (
              <TableRow key={invoice.id}>
                {currentUser.user_type !== 'Aluno' && (
                  <TableCell>{invoice.student_name || `Aluno ${invoice.student_id}`}</TableCell>
                )}
                <TableCell>{invoice.plan_name || `Plano ${invoice.plan_id}`}</TableCell>
                <TableCell>R$ {parseFloat(invoice.value).toFixed(2)}</TableCell>
                <TableCell>
                  {invoice.due_date ? new Date(invoice.due_date).toLocaleDateString('pt-BR') : 'Não definida'}
                </TableCell>
                <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                    
                    {invoice.status === 'Pendente' && (
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-green-500"
                        onClick={() => handlePayment(invoice.id)}
                      >
                        <CreditCard className="h-4 w-4" />
                      </Button>
                    )}
                    
                    {canManageInvoices && (
                      <>
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(invoice)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(invoice.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }
};

export default Invoices;

